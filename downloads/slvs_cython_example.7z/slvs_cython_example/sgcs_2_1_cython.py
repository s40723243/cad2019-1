'''
python3 -m pip install matplotlib
Point0 (0, 0)
Point1(90, 0)
Point2 is the tip of the triangle
link1 length 35
link2 length 70
link3 length 70
triangle length 70, 40, 40
'''
from slvs import *
from math import *
import matplotlib.pyplot as plt

def crank_rocker(degree, p1x, p1y, p2x, p2y, p3x, p3y, p4x, p4y):
    """Crank rocker example."""
    sys = SolverSystem()
    # working plane
    wp = sys.create_2d_base()
    # origin zero
    p0 = sys.add_point_2d(0, 0, wp)
    sys.dragged(p0, wp)
    #p1 = sys.add_point_2d(90, 0, wp)
    p1 = sys.add_point_2d(p1x, p1y, wp)
    sys.dragged(p1, wp)
    line0 = sys.add_line_2d(p0, p1, wp)
    #p2 = sys.add_point_2d(20, 20, wp)
    p2 = sys.add_point_2d(p2x, p2y, wp)
    #p3 = sys.add_point_2d(0, 10, wp)
    p3 = sys.add_point_2d(p3x, p3y, wp)
    #p4 = sys.add_point_2d(30, 20, wp)
    p4 = sys.add_point_2d(p4x, p4y, wp)
    sys.distance(p2, p3, 40, wp)
    sys.distance(p2, p4, 40, wp)
    sys.distance(p3, p4, 70, wp)

    sys.distance(p0, p3, 35, wp)
    sys.distance(p1, p4, 70, wp)
    line1 = sys.add_line_2d(p0, p3, wp)

    #sys.angle(line0, line1, 45, wp)
    sys.angle(line0, line1, degree, wp)

    result_flag = sys.solve()
    #print(result_flag) #ResultFlag.OKAY
    x2, y2 = sys.params(p2.params)
    #x3, y3 = sys.params(p3.params)
    x4, y4 = sys.params(p4.params)
    return x2, y2, x4, y4
'''
# first test
x, y = crank_rocker(45, 90, 0, 20, 20, 0, 10, 30, 20)    
print(x) #39.54852
print(y) #61.91009
'''
# main program
Xval  = []
Yval  = []
inc = 5
# initially Point3, Point4, Point5 coordinate
len1 = 35 # link 1 length
p1x = 90
p1y = 0
p2x = 20
p2y = 20
p3x = 0
p3y = 10
p4x = 30
p4y = 20
for i in range(0, 360+inc, inc):
    p3x = len1*cos(i*pi/180)
    p3y = len1*sin(i*pi/180)
    try:
        p2x, p2y, p4x, p4y = crank_rocker(i, p1x, p1y, p2x, p2y, p3x, p3y, p4x, p4y)
        Xval += [p2x]
        Yval += [p2y]
        print(i, ":", round(p2x, 4), round(p2y, 4))
    except:
        pass
print ("Solve Completed")

plt.plot(Xval, Yval)
plt.xlabel('x coordinate')
plt.ylabel('y coordinate')
plt.show()