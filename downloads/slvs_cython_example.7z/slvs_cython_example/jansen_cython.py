from slvs import *
from math import *
import matplotlib.pyplot as plt

def jansen_linkage(angle, points):
    """Jansen's linkage example."""
    [pdx, pdy,
      pex, pey,
      pfx, pfy,
      pgx, pgy,
      phx, phy,
      pkx, pky] = points
      
    sys = SolverSystem()
    wp = sys.create_2d_base()
    
    # point a is  fixed
    pa = sys.add_point_2d(-38, -7.8, wp)
    sys.dragged(pa, wp)
    # origin c is fixed
    pc = sys.add_point_2d(0, 0, wp)
    sys.dragged(pc, wp)
    pm = sys.add_point_2d(20, 0, wp)
    sys.dragged(pm, wp)
    ref = sys.add_line_2d(pc, pm, wp)
    
    # point d
    #pd = sys.add_point_2d(0, 20, wp)
    pd = sys.add_point_2d(pdx, pdy, wp)
    # cd line is the driver
    driver = sys.add_line_2d(pc, pd, wp)
    # point e
    #pe = sys.add_point_2d(-50, 30, wp)
    pe = sys.add_point_2d(pex, pey, wp)
    # point f
    #pf = sys.add_point_2d(-70, -15, wp)
    pf = sys.add_point_2d(pfx, pfy, wp)
    # point g
    #pg = sys.add_point_2d(-50, -50, wp)
    pg = sys.add_point_2d(pgx, pgy, wp)
    # point h
    #p7 = sys.add_point_2d(-20, -40, wp)
    ph = sys.add_point_2d(phx, phy, wp)
    # point k
    #pk = sys.add_point_2d(-10, -90, wp)
    pk = sys.add_point_2d(pkx, pky, wp)
    
    # ed line length is 50 -- 1
    sys.distance(pe, pd, 50, wp)
    # ef line length is 55.8 -- 2
    sys.distance(pe, pf, 55.8, wp)
    # af line length -- 3
    sys.distance(pa, pf, 40.1, wp)
    # ae line length is 41.5 -- 4
    sys.distance(pa, pe, 41.5, wp)
    # cd line length is 15 -- 5
    sys.distance(pc, pd, 15, wp)
    # fg line length = 39.4 -- 6
    sys.distance(pf, pg, 39.4, wp)
    # gk line length is 65.7 -- 7
    sys.distance(pg, pk, 65.7, wp)
    # gh line length -- 8
    sys.distance(pg, ph, 36.7, wp)
    # kh line length is 49 -- 9
    sys.distance(pk, ph, 49.0, wp)
    # ah line length = 39.3 -- 10
    sys.distance(pa, ph, 39.3, wp)
    # hd line length is 61.9 -- 11
    sys.distance(ph, pd, 61.9, wp)

    sys.angle(driver, ref, angle, wp)
    
    result_flag = sys.solve()
    
    xd, yd = sys.params(pd.params)
    xe, ye = sys.params(pe.params)
    xf, yf  =  sys.params(pf.params)
    xg, yg = sys.params(pg.params)
    xh, yh = sys.params(ph.params)
    xk, yk = sys.params(pk.params)

    points = [xd, yd,
      xe, ye,
      xf, yf,
      xg, yg,
      xh, yh,
      xk, yk]
    return points

# main program
Xval  = []
Yval  = []
inc = 2
len1 = 15
points = [11.02, 10.18,
  -33.25, 33.43,
  -77.45, -0.63,
  -56.1, -33.74,
  -20.6, -43.04,
  -25.36, -91.81] 
 
'''
points = jansen_linkage(130, points)
print(points[10], points[11])
'''

for i in range(0, 360+inc, inc):
    points[0] = len1*cos(i*pi/180)
    points[1] = len1*sin(i*pi/180)
    try:
        outpoints = jansen_linkage(i, points)
        Xval += [outpoints[10]]
        Yval += [outpoints[11]]
    except:
        print("error", i)
print ("Solve Completed")
#print(Xval)
#print(Yval)
plt.plot(Xval, Yval)
plt.xlabel('x coordinate')
plt.ylabel('y coordinate')
plt.show()
