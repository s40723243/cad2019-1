// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.2 Rev1 on September 5th 2015

#pragma once

#include "MainCont.h"
#include "LuaScriptObject.h"
#include "LuaObjectGroup.h"
#include "BroadcastDataContainer.h"
#include "v_rep_internal.h"
#include "VMenubar.h"


#define ADDON_SCRIPT_PREFIX_AUTOSTART "vrepAddOnScript_"
#define ADDON_SCRIPT_PREFIX_NOAUTOSTART "vrepAddOnScript-"
#define ADDON_FUNCTION_PREFIX "vrepAddOnFunc_"
#define ADDON_EXTENTION "lua"

class CLuaScriptContainer : public CMainCont 
{
public:
	CLuaScriptContainer();
	virtual ~CLuaScriptContainer();
	void simulationAboutToStart();
	void simulationEnded();
	void simulationAboutToEnd();
	void renderYour3DStuff(CViewableBase* renderingObject,int displayAttrib);
	void removeAllScripts(bool keepAddOnScripts);
	void announceObjectWillBeErased(int objectID);
	void addMenu(VMenu* menu);
	bool processCommand(int commandID);
	bool removeScript_safe(int scriptId);
	bool removeScript(int scriptID);
	int insertScript(CLuaScriptObject* script);
	CLuaScriptObject* getScriptFromID(int scriptID);
	CLuaScriptObject* getMainOrChildScriptFromPseudoName(std::string scriptPseudoName);
	CLuaScriptObject* getMainScript();
	CLuaScriptObject* getScriptFromObjectAttachedTo_child(int threeDObjectID);
	CLuaScriptObject* getScriptFromObjectAttachedTo_callback(int threeDObjectID);
	CLuaScriptObject* getScriptFromObjectAttachedTo_customization(int threeDObjectID);
	CLuaScriptObject* getCustomContactHandlingScript_callback();
	CLuaScriptObject* getGeneralCallbackHandlingScript_callback();
	void killAllSimulationLuaStates();
	int insertDefaultScript_mainAndChildScriptsOnly(int scriptType,bool threaded);
	int insertAddOnScripts();
	int prepareAddOnFunctionNames();
	void setInMainScriptNow(bool launched,int startTimeInMs);
	bool getInMainScriptNow();
	int getMainScriptExecTimeInMs();
	void setInAddOnNow(bool inAddOn);
	bool getInAddOnNow();
	void setInLuaCallbackNow(bool inCallback);
	bool getInLuaCallbackNow();
	void setInCustomizationScriptNow(bool inCustomizationScript);
	bool getInCustomizationScriptNow();

	int removeDestroyedScripts(int scriptType);

	void addCallbackStructureObjectToDestroyAtTheEndOfSimulation(SLuaCallBack* object);
	bool addCommandToOutsideCommandQueues(int commandID,int auxVal1,int auxVal2,int auxVal3,int auxVal4,const float aux2Vals[8],int aux2Count);

	void handleAddOnScriptExecution();
	int handleCustomizationScriptExecution(int callType);

	static void setAdditionalAddOnScript(std::string scriptNameWithExtension,bool firstSceneOnly);

	std::vector<CLuaScriptObject*> allScripts;

	std::vector<std::string> allAddOnFunctionNames;

	int getScriptSimulationParameter_mainAndChildScriptsOnly(int scriptHandle,const char* parameterName,std::string& parameterValue);
	int setScriptSimulationParameter_mainAndChildScriptsOnly(int scriptHandle,const char* parameterName,const char* parameterValue,int parameterValueLength);

	CBroadcastDataContainer broadcastDataContainer;

protected:
	bool _inMainScriptNow;
	int _mainScriptStartTimeInMs;
	bool _inAddOnNow;
	bool _inCallbackNow;
	bool _inCustomizationScriptNow;

	std::vector<SLuaCallBack*> _callbackStructureToDestroyAtEndOfSimulation;
	static std::string _additionalAddOnScriptFirstScene;
	static std::string _additionalAddOnScriptAllScenes;
};
