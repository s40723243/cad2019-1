// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.2 Rev1 on September 5th 2015

// Not very elegant. Needs refactoring!!

#include "vrepPrecompiledHeader.h"
#include "qdlgmaterial.h"
#include "ui_qdlgmaterial.h"
#include "GV.h"
#include "Tt.h"
#include "App.h"
#include "qdlgcolorpulsation.h"

CQDlgMaterial::CQDlgMaterial(QWidget *parent) :
	CDlgEx(parent),
	ui(new Ui::CQDlgMaterial)
{
    ui->setupUi(this);
	inMainRefreshRoutine=false;
	ambientDiffuse=NULL;
	specular=NULL;
	emissive=NULL;
	auxiliaryChannels=NULL;
	transparencyFactor=NULL;
	povPatternType=NULL;
	shininess=NULL;
	transparency=NULL;
	flashing=NULL;
	simulationTimeFlashing=NULL;
	flashingFrequency=NULL;
	flashingPhase=NULL;
	flashingRatio=NULL;
	color=NULL;
	colorName=NULL;
	_identification[0]=-1;
	_identification[1]=-1;
	_identification[2]=-1;
	_identification[3]=-1;
	isModal=false;
	if (App::mainWindow!=NULL)
		App::mainWindow->dlgCont->close(COLOR_DLG);
}

CQDlgMaterial::~CQDlgMaterial()
{
    delete ui;
	if (App::mainWindow!=NULL)
		App::mainWindow->dlgCont->close(COLOR_DLG);
}

void CQDlgMaterial::refresh()
{
	inMainRefreshRoutine=true;
	ui->qqAmbientAdjust->setEnabled(ambientDiffuse!=NULL);
	ui->qqSpecularAdjust->setEnabled(specular!=NULL);
	ui->qqEmissiveAdjust->setEnabled(emissive!=NULL);
	ui->qqAuxiliaryAdjust->setEnabled(auxiliaryChannels!=NULL);
	ui->qqPulsationAdjust->setEnabled(flashing!=NULL);
	ui->qqShininess->setEnabled(shininess!=NULL);

	if (shininess!=NULL)
		ui->qqShininess->setText(tt::getIString(false,shininess[0]).c_str());
	else
		ui->qqShininess->setText("");
	ui->qqOpacityEnable->setEnabled(transparency!=NULL);
	if (transparency!=NULL)
	{
		ui->qqOpacityEnable->setChecked(transparency[0]);
		ui->qqOpacity->setEnabled(transparency[0]);
		ui->qqOpacity->setText(tt::getFString(false,transparencyFactor[0],2).c_str());
	}
	else
	{
		ui->qqOpacityEnable->setChecked(0);
		ui->qqOpacity->setEnabled(false);
		ui->qqOpacity->setText("");
	}

	ui->qqColorName->setEnabled(colorName!=NULL);
	if (colorName!=NULL)
		ui->qqColorName->setText(colorName->c_str());
	else
		ui->qqColorName->setText("");

	ui->qqPov->clear();
	ui->qqPov->setEnabled(povPatternType!=NULL);
	if (povPatternType!=NULL)
	{
		ui->qqPov->addItem("default",QVariant(sim_pov_pattern_null));
		ui->qqPov->addItem("white marble",QVariant(sim_pov_white_marble));
		ui->qqPov->addItem("blood marble",QVariant(sim_pov_blood_marble));
		ui->qqPov->addItem("blue agate",QVariant(sim_pov_blue_agate));
		ui->qqPov->addItem("sapphire agate",QVariant(sim_pov_sapphire_agate));
		ui->qqPov->addItem("brown agate",QVariant(sim_pov_brown_agate));
		ui->qqPov->addItem("pink granite",QVariant(sim_pov_pink_granite));
		ui->qqPov->addItem("pink alabaster",QVariant(sim_pov_pink_alabaster));
		ui->qqPov->addItem("cherry wood",QVariant(sim_pov_cherry_wood));
		ui->qqPov->addItem("pine wood",QVariant(sim_pov_pine_wood));
		ui->qqPov->addItem("dark wood",QVariant(sim_pov_dark_wood));
		ui->qqPov->addItem("tan wood",QVariant(sim_pov_tan_wood));
		ui->qqPov->addItem("white wood",QVariant(sim_pov_white_wood));
		ui->qqPov->addItem("tom wood",QVariant(sim_pov_tom_wood));
		ui->qqPov->addItem("dmf wood1",QVariant(sim_pov_dmf_wood1));
		ui->qqPov->addItem("dmf wood2",QVariant(sim_pov_dmf_wood2));
		ui->qqPov->addItem("dmf wood3",QVariant(sim_pov_dmf_wood3));
		ui->qqPov->addItem("dmf wood4",QVariant(sim_pov_dmf_wood4));
		ui->qqPov->addItem("dmf wood5",QVariant(sim_pov_dmf_wood5));
		ui->qqPov->addItem("dmf wood6",QVariant(sim_pov_dmf_wood6));
		ui->qqPov->addItem("dmf light oak",QVariant(sim_pov_dmf_light_oak));
		ui->qqPov->addItem("dmf dark oak",QVariant(sim_pov_dmf_dark_oak));
		ui->qqPov->addItem("emb wood1",QVariant(sim_pov_emb_wood1));
		ui->qqPov->addItem("yellow pine",QVariant(sim_pov_yellow_pine));
		ui->qqPov->addItem("rose wood",QVariant(sim_pov_rose_wood));
		ui->qqPov->addItem("sandal wood",QVariant(sim_pov_sandal_wood));
		ui->qqPov->addItem("glass",QVariant(sim_pov_glass));
		ui->qqPov->addItem("glass2",QVariant(sim_pov_glass2));
		ui->qqPov->addItem("glass3",QVariant(sim_pov_glass3));
		ui->qqPov->addItem("green glass",QVariant(sim_pov_green_glass));
		ui->qqPov->addItem("light glass",QVariant(sim_pov_light_glass));
		ui->qqPov->addItem("bold glass",QVariant(sim_pov_bold_glass));
		ui->qqPov->addItem("wine bottle",QVariant(sim_pov_wine_bottle));
		ui->qqPov->addItem("beer bottle",QVariant(sim_pov_beer_bottle));
		ui->qqPov->addItem("ruby glass",QVariant(sim_pov_ruby_glass));
		ui->qqPov->addItem("blue glass",QVariant(sim_pov_blue_glass));
		ui->qqPov->addItem("yellow glass",QVariant(sim_pov_yellow_glass));
		ui->qqPov->addItem("orange glass",QVariant(sim_pov_orange_glass));
		ui->qqPov->addItem("vicks bottle glass",QVariant(sim_pov_vicks_bottle_glass));
		ui->qqPov->addItem("chrome metal",QVariant(sim_pov_chrome_metal));
		ui->qqPov->addItem("brass metal",QVariant(sim_pov_brass_metal));
		ui->qqPov->addItem("copper metal",QVariant(sim_pov_copper_metal));
		ui->qqPov->addItem("bronze metal",QVariant(sim_pov_bronze_metal));
		ui->qqPov->addItem("silver metal",QVariant(sim_pov_silver_metal));
		ui->qqPov->addItem("gold metal",QVariant(sim_pov_gold_metal));
		ui->qqPov->addItem("polished chrome",QVariant(sim_pov_polished_chrome));
		ui->qqPov->addItem("polished brass",QVariant(sim_pov_polished_brass));
		ui->qqPov->addItem("new brass",QVariant(sim_pov_new_brass));
		ui->qqPov->addItem("spun brass",QVariant(sim_pov_spun_brass));
		ui->qqPov->addItem("brushed aluminium",QVariant(sim_pov_brushed_aluminum));
		ui->qqPov->addItem("silver1",QVariant(sim_pov_silver1));
		ui->qqPov->addItem("silver2",QVariant(sim_pov_silver2));
		ui->qqPov->addItem("silver3",QVariant(sim_pov_silver3));
		ui->qqPov->addItem("brass valley",QVariant(sim_pov_brass_valley));
		ui->qqPov->addItem("rust",QVariant(sim_pov_rust));
		ui->qqPov->addItem("rusty iron",QVariant(sim_pov_rusty_iron));
		ui->qqPov->addItem("soft silver",QVariant(sim_pov_soft_silver));
		ui->qqPov->addItem("new penny",QVariant(sim_pov_new_penny));
		ui->qqPov->addItem("tiny brass",QVariant(sim_pov_tinny_brass));
		ui->qqPov->addItem("gold nugget",QVariant(sim_pov_gold_nugget));
		ui->qqPov->addItem("aluminium",QVariant(sim_pov_aluminum));
		ui->qqPov->addItem("bright bronze",QVariant(sim_pov_bright_bronze));
		ui->qqPov->addItem("water",QVariant(sim_pov_water));
		ui->qqPov->addItem("cork",QVariant(sim_pov_cork));
		ui->qqPov->addItem("lightning",QVariant(sim_pov_lightning));
		ui->qqPov->addItem("mirror",QVariant(sim_pov_mirror));
		ui->qqPov->setCurrentIndex(povPatternType[0]);
	}
	inMainRefreshRoutine=false;
}

bool CQDlgMaterial::needsDestruction()
{
	if (!isLinkedDataValid())
		return(true);
	return(CDlgEx::needsDestruction());
}

void CQDlgMaterial::displayMaterialDlgModal(int identification[4],QWidget* theParentWindow,float ambientDiffuseP[3],float specularP[3],float emissiveP[3],float auxiliaryP[3],bool* flashingP,int* shininessP,bool* transparencyP,float* transparencyFactorP,std::string* theColorName)
{	// Any value of ambient, diffuse, etc. can be NULL.
	// If a value is NULL, it can't be adjusted.
	if (App::mainWindow==NULL)
		return;
	App::mainWindow->dlgCont->close(MATERIAL_DLG);
	App::mainWindow->dlgCont->close(COLOR_DLG);

	CQDlgMaterial it(theParentWindow);
	it._initialize(identification,ambientDiffuseP,specularP,emissiveP,auxiliaryP,flashingP,shininessP,transparencyP,transparencyFactorP,NULL,theColorName);
	it.isModal=true;
	it.makeDialogModal();
}

void CQDlgMaterial::_initialize(int identification[4],float ambientDiffuseP[3],float specularP[3],float emissiveP[3],float auxiliaryP[3],bool* flashingP,int* shininessP,bool* transparencyP,float* transparencyFactorP,bool* flashSimTimeP,std::string* theColorName)
{
	_identification[0]=identification[0];
	_identification[1]=identification[1];
	_identification[2]=identification[2];
	_identification[3]=identification[3];
	ambientDiffuse=ambientDiffuseP;
	specular=specularP;
	emissive=emissiveP;
	auxiliaryChannels=auxiliaryP;
	flashing=NULL;
	simulationTimeFlashing=flashSimTimeP;
	flashingFrequency=NULL;
	flashingPhase=NULL;
	flashingRatio=NULL;
	shininess=shininessP;
	colorName=theColorName;
	if ((transparencyP==NULL)||(transparencyFactorP==NULL))
	{
		transparency=NULL;
		transparencyFactor=NULL;
	}
	else
	{
		transparency=transparencyP;
		transparencyFactor=transparencyFactorP;
	}
	refresh();
}

void CQDlgMaterial::_initialize(int identification[4],CVisualParam* it,bool ambDiff,bool spec,
					bool emiss,bool aux,bool shin,bool transp,bool allowFlashing,bool colorNameEnabled,bool povPatternEnabled)
{ // All boolean value are true by default! If a value is true, it can be adjusted
	_identification[0]=identification[0];
	_identification[1]=identification[1];
	_identification[2]=identification[2];
	_identification[3]=identification[3];
	ambientDiffuse=it->colors+0;
	specular=it->colors+6;
	emissive=it->colors+9;
	auxiliaryChannels=it->colors+12;
	if (allowFlashing)
	{
		flashing=&it->flash;
		simulationTimeFlashing=&it->useSimulationTime;
		flashingFrequency=&it->flashFrequency;
		flashingPhase=&it->flashPhase;
		flashingRatio=&it->flashRatio;
	}
	else
	{
		flashing=NULL;
		simulationTimeFlashing=NULL;
		flashingFrequency=NULL;
		flashingPhase=NULL;
		flashingRatio=NULL;
	}
	shininess=&it->shininess;
	transparency=&it->translucid;
	transparencyFactor=&it->transparencyFactor;
	colorName=&it->colorName;
	povPatternType=&it->povPatternType;
	if (!ambDiff)
		ambientDiffuse=NULL;
	if (!spec)
		specular=NULL;
	if (!emiss)
		emissive=NULL;
	if (!aux)
		auxiliaryChannels=NULL;
	if (!shin)
		shininess=NULL;
	if (!transp)
	{
		transparency=NULL;
		transparencyFactor=NULL;
	}
	if (!colorNameEnabled)
		colorName=NULL;
	if (!povPatternEnabled)
		povPatternType=NULL;
	refresh();
}

bool CQDlgMaterial::isLinkedDataValid()
{
	if (_identification[1]==3)
	{ // we have a CGeometric object in multishape edition here.
		if (App::ct->objCont->getEditModeType()!=MULTISHAPE_EDIT_MODE)
			return(false);
		if (_identification[0]!=App::ct->objCont->_multishapeGeometricComponentIndex)
			return(false);
		return(true);
	}
	if (!CLifeControl::isAlive(_identification[0]))
		return(false);
	if (_identification[1]==0)
	{ // we have a 3DObject here
		if (App::ct->objCont!=NULL)
		{
			if (App::ct->objCont->getLastSelectionID()!=_identification[2])
				return(false);
		}
	}
	return(true);
}

void CQDlgMaterial::displayMaterialDlg(int identification[4],CVisualParam* it,QWidget* theParentWindow,bool ambDiff,bool spec,
					bool emiss,bool aux,bool shin,bool transp,bool flashing,bool colorNameEnabled,bool povPatternEnabled)
{ // All boolean value are true by default! If a value is true, it can be adjusted
	if (App::mainWindow==NULL)
		return;
	App::mainWindow->dlgCont->close(MATERIAL_DLG);
	App::mainWindow->dlgCont->close(COLOR_DLG);
	if (App::mainWindow->dlgCont->openOrBringToFront(MATERIAL_DLG))
	{
		CQDlgMaterial* mat=(CQDlgMaterial*)App::mainWindow->dlgCont->getDialog(MATERIAL_DLG);
		if (mat!=NULL)
			mat->_initialize(identification,it,ambDiff,spec,emiss,aux,shin,transp,flashing,colorNameEnabled,povPatternEnabled);
	}
}

void CQDlgMaterial::colorAdjust(float* col)
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (col!=NULL)
		{
			if (!isModal)
			{
				if (isLinkedDataValid())
				{
					if (App::mainWindow->dlgCont->openOrBringToFront(COLOR_DLG))
					{
						CQDlgColor* it=(CQDlgColor*)App::mainWindow->dlgCont->getDialog(COLOR_DLG);
						if (it!=NULL)
							it->initialize(col,_identification);
					}
				}
			}
			else
			{
				CQDlgColor it(this);
				it.initialize(col,_identification);
				it.makeDialogModal();
			}
		}
	}
}

void CQDlgMaterial::cancelEvent()
{ // We just hide the dialog and destroy it at next rendering pass
	ambientDiffuse=NULL;
	specular=NULL;
	emissive=NULL;
	auxiliaryChannels=NULL;
	flashing=NULL;
	transparencyFactor=NULL;
	shininess=NULL;
	transparency=NULL;
	if (((QDialog*)this)->isModal()) // this condition and next line on 31/3/2013: on Linux the dlg couldn't be closed!
		defaultModalDialogEndRoutine(false);
	else
		CDlgEx::cancelEvent();
}

bool CQDlgMaterial::doesInstanceSwitchRequireDestruction()
{
	return(true);
}

void CQDlgMaterial::on_qqAmbientAdjust_clicked()
{
	colorAdjust(ambientDiffuse);
}

void CQDlgMaterial::on_qqSpecularAdjust_clicked()
{
	colorAdjust(specular);
}

void CQDlgMaterial::on_qqEmissiveAdjust_clicked()
{
	colorAdjust(emissive);
}

void CQDlgMaterial::on_qqPulsationAdjust_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (flashing!=NULL)
		{
			CQDlgColorPulsation theDialog(this);
			theDialog.pulsationEnabled=flashing[0];
			theDialog.pulsationRealTime=!simulationTimeFlashing[0];
			theDialog.pulsationFrequency=flashingFrequency[0];
			theDialog.pulsationPhase=flashingPhase[0];
			theDialog.pulsationRatio=flashingRatio[0];
			theDialog.refresh();
			if (theDialog.makeDialogModal()!=VDIALOG_MODAL_RETURN_CANCEL)
			{
				flashing[0]=theDialog.pulsationEnabled;
				simulationTimeFlashing[0]=!theDialog.pulsationRealTime;
				flashingFrequency[0]=theDialog.pulsationFrequency;
				flashingPhase[0]=theDialog.pulsationPhase;
				flashingRatio[0]=theDialog.pulsationRatio;
			}
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
			refresh();
		}
	}
}

void CQDlgMaterial::on_qqShininess_editingFinished()
{
	if (!ui->qqShininess->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!isLinkedDataValid())
			return;
		if (shininess==NULL)
			return;
		bool ok;
		float newVal=ui->qqShininess->text().toFloat(&ok);
		if (ok)
		{
			shininess[0]=tt::getLimitedInt(0,128,newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgMaterial::on_qqOpacityEnable_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!isLinkedDataValid())
			return;
		if (transparency==NULL)
			return;
		transparency[0]=!transparency[0];
		if (_identification[1]==0)
		{ // we have a 3D object here
			CShape* it=App::ct->objCont->getShape(_identification[2]);
			if (it!=NULL)
			{ // we have a shape here
				// Now let's check if the outside and inside faces are transparent:
				it->actualizeContainsTransparentComponent();
			}
		}
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgMaterial::on_qqOpacity_editingFinished()
{
	if (!ui->qqOpacity->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!isLinkedDataValid())
			return;
		if (transparencyFactor==NULL)
			return;
		bool ok;
		float newVal=ui->qqOpacity->text().toFloat(&ok);
		if (ok)
		{
			transparencyFactor[0]=tt::getLimitedFloat(0.0f,1.0f,newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgMaterial::on_qqColorName_editingFinished()
{
	if (!ui->qqColorName->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!isLinkedDataValid())
			return;
		if (colorName==NULL)
			return;
		colorName[0]=ui->qqColorName->text().toStdString();
		tt::removeIllegalCharacters(colorName[0],false);
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}


void CQDlgMaterial::on_qqAuxiliaryAdjust_clicked()
{
	colorAdjust(auxiliaryChannels);
}

void CQDlgMaterial::on_qqPov_currentIndexChanged(int index)
{
	if (!inMainRefreshRoutine)
	{
		IF_UI_EVENT_CAN_READ_DATA
		{
			if (!isLinkedDataValid())
				return;
			if (povPatternType==NULL)
				return;
			povPatternType[0]=index;
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
			refresh();
		}
	}
}
