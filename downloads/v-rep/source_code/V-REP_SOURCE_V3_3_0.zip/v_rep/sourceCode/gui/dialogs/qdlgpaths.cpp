// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2016 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.3.0 on February 19th 2016

#include "vrepMainHeader.h"
#include "qdlgpaths.h"
#include "ui_qdlgpaths.h"
#include "Tt.h"
#include "GV.h"
#include "qdlgmaterial.h"
#include "App.h"
#include "qdlgpathshaping.h"
#include "v_repStrings.h"

CQDlgPaths::CQDlgPaths(QWidget *parent) :
	CDlgEx(parent),
    ui(new Ui::CQDlgPaths)
{
    ui->setupUi(this);
	inMainRefreshRoutine=false;
}

CQDlgPaths::~CQDlgPaths()
{
    delete ui;
}

void CQDlgPaths::cancelEvent()
{
	// we override this cancel event. The container window should close, not this one!!
	App::mainWindow->dlgCont->close(OBJECT_DLG);
}

void CQDlgPaths::refresh()
{
	inMainRefreshRoutine=true;
	bool sel=App::ct->objCont->isLastSelectionAPath();
	bool ssel=sel&&(App::ct->objCont->getPathNumberInSelection()>1);
	bool noSim=App::ct->simulation->isSimulationStopped();

	if (App::getEditModeType()!=NO_EDIT_MODE)
	{
		sel=false;
		ssel=false;
	}
	CPath* path=NULL;
	CPathCont* pathCont=NULL;
	if (sel)
	{
		path=(CPath*)App::ct->objCont->getLastSelection();
		pathCont=path->pathContainer;
	}

	ui->qqShowOrientation->setEnabled(sel);
	ui->qqShowPathLine->setEnabled(sel);
	ui->qqShowPosition->setEnabled(sel);
	ui->qqAdjustColor->setEnabled(sel);
	ui->qqLineSize->setEnabled(sel);
	ui->qqControlPointSize->setEnabled(sel);
	ui->qqDistanceCombo->setEnabled(sel&&noSim);

	ui->qqShowShapingDialog->setEnabled(sel);
	ui->qqShowShapingDialog->setChecked(CQDlgPathShaping::showWindow);

	ui->qqShowOrientation->setChecked((pathCont!=NULL)&&((pathCont->getAttributes()&sim_pathproperty_show_orientation)!=0));
	ui->qqShowPathLine->setChecked((pathCont!=NULL)&&((pathCont->getAttributes()&sim_pathproperty_show_line)!=0));
	ui->qqShowPosition->setChecked((pathCont!=NULL)&&((pathCont->getAttributes()&sim_pathproperty_show_position)!=0));
	ui->qqDistanceCombo->clear();

	if (pathCont!=NULL)
	{
		ui->qqLineSize->setText(tt::getIString(false,pathCont->getLineSize()).c_str());
		ui->qqControlPointSize->setText(tt::getFString(false,pathCont->getSquareSize(),3).c_str());

		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_DL),QVariant(sim_distcalcmethod_dl));
		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_DAC),QVariant(sim_distcalcmethod_dac));
		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_MAX_DL_DAC),QVariant(sim_distcalcmethod_max_dl_dac));
		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_DL_AND_DAC),QVariant(sim_distcalcmethod_dl_and_dac));
		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_SQRT_DL2_AND_DAC2),QVariant(sim_distcalcmethod_sqrt_dl2_and_dac2));
		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_DL_IF_NONZERO),QVariant(sim_distcalcmethod_dl_if_nonzero));
		ui->qqDistanceCombo->addItem(strTranslate(IDS_PATH_LENGTH_CALC_DAC_IF_NONZERO),QVariant(sim_distcalcmethod_dac_if_nonzero));
		for (int i=0;i<ui->qqDistanceCombo->count();i++)
		{
			if (ui->qqDistanceCombo->itemData(i).toInt()==pathCont->getPathLengthCalculationMethod())
			{
				ui->qqDistanceCombo->setCurrentIndex(i);
				break;
			}
		}
	}
	else
	{
		ui->qqLineSize->setText("");
		ui->qqControlPointSize->setText("");
	}

	inMainRefreshRoutine=false;
}

CPathCont* CQDlgPaths::getPathCont()
{
	CPathCont* pathCont=NULL;
	if (App::getEditModeType()==PATH_EDIT_MODE)
		pathCont=App::mainWindow->editModeContainer->getEditModePathContainer();
	else
	{
		CPath* path=App::ct->objCont->getPath(App::ct->objCont->getLastSelectionID());
		if (path!=NULL)
			pathCont=path->pathContainer;
	}
	return(pathCont);
}

CPath* CQDlgPaths::getPath()
{
	CPath* path=App::ct->objCont->getPath(App::ct->objCont->getLastSelectionID());
	return(path);
}


void CQDlgPaths::on_qqShowOrientation_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_show_orientation);
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgPaths::on_qqShowPathLine_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_show_line);
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgPaths::on_qqShowPosition_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_show_position);
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgPaths::on_qqAdjustColor_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		int identification[4]={pathCont->getLifeID(),-1,-1,-1};
		CQDlgMaterial::displayMaterialDlg(identification,&pathCont->_lineColor,App::mainWindow,true,true,true,true,true,false,true,false,false);
	}
}

void CQDlgPaths::on_qqLineSize_editingFinished()
{
	if (!ui->qqLineSize->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		bool ok;
		int newVal=ui->qqLineSize->text().toInt(&ok);
		if (ok)
		{
			pathCont->setLineSize(newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgPaths::on_qqControlPointSize_editingFinished()
{
	if (!ui->qqControlPointSize->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		bool ok;
		float newVal=ui->qqControlPointSize->text().toFloat(&ok);
		if (ok)
		{
			pathCont->setSquareSize(newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgPaths::on_qqDistanceCombo_currentIndexChanged(int index)
{
	if (!inMainRefreshRoutine)
	{
		IF_UI_EVENT_CAN_WRITE_DATA
		{
			CPathCont* pathCont=getPathCont();
			if (pathCont==NULL)
				return;
			pathCont->setPathLengthCalculationMethod(ui->qqDistanceCombo->itemData(ui->qqDistanceCombo->currentIndex()).toInt());
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
			refresh();
		}
	}
}

void CQDlgPaths::on_qqShowShapingDialog_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CQDlgPathShaping::showWindow=!CQDlgPathShaping::showWindow;
		if (App::mainWindow->dlgCont->isVisible(PATH_SHAPING_DLG)!=CQDlgPathShaping::showWindow)
			App::mainWindow->dlgCont->toggle(PATH_SHAPING_DLG);
	}
}
