// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2016 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.3.0 on February 19th 2016

#include "vrepMainHeader.h"
#include "qdlgpathedit.h"
#include "ui_qdlgpathedit.h"
#include "App.h"
#include "GV.h"
#include "Tt.h"
#include "v_repStrings.h"
#include <boost/lexical_cast.hpp>

CQDlgPathEdit::CQDlgPathEdit(QWidget *parent) :
	CDlgEx(parent),
    ui(new Ui::CQDlgPathEdit)
{
    ui->setupUi(this);
}

CQDlgPathEdit::~CQDlgPathEdit()
{
    delete ui;
}

void CQDlgPathEdit::cancelEvent()
{
	App::mainWindow->editModeContainer->processCommand(ANY_EDIT_MODE_FINISH_WITH_QUESTION_DLG_EMCMD,NULL);
//	defaultModalDialogEndRoutine(false);
}

void CQDlgPathEdit::okEvent()
{
//	defaultModalDialogEndRoutine(true);
}

void CQDlgPathEdit::refresh()
{
	if (App::getEditModeType()!=PATH_EDIT_MODE)
		return;
	CPathCont* pathCont=App::mainWindow->editModeContainer->getEditModePathContainer();
	int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();

	ui->qqClosed->setChecked(((pathCont->getAttributes()&sim_pathproperty_closed_path)!=0));
	ui->qqFlat->setChecked(((pathCont->getAttributes()&sim_pathproperty_flat_path)!=0));
	ui->qqAutomaticOrientation->setChecked(((pathCont->getAttributes()&sim_pathproperty_automatic_orientation)!=0));
	ui->qqKeepXup->setChecked(((pathCont->getAttributes()&sim_pathproperty_keep_x_up)!=0));

	std::string tmp=std::string(IDS_TOTAL_PATH_POINTS)+": "+boost::lexical_cast<std::string>(App::mainWindow->editModeContainer->getEditModeBufferSize())+"/"+
		boost::lexical_cast<std::string>(App::mainWindow->editModeContainer->getEditModePathContainer()->getSimplePathPointCount());
	ui->qqInfo->setText(tmp.c_str());

	ui->qqMakeDummies->setEnabled(selectedPointCount!=0);

	ui->qqFactor1->setEnabled(selectedPointCount!=0);
	ui->qqFactor2->setEnabled(selectedPointCount!=0);
	ui->qqPointCount->setEnabled(selectedPointCount!=0);
	ui->qqVirtualDistance->setEnabled(selectedPointCount!=0);
	ui->qqAuxFlags->setEnabled(selectedPointCount!=0);
	ui->qqAuxChannel1->setEnabled(selectedPointCount!=0);
	ui->qqAuxChannel2->setEnabled(selectedPointCount!=0);
	ui->qqAuxChannel3->setEnabled(selectedPointCount!=0);
	ui->qqAuxChannel4->setEnabled(selectedPointCount!=0);

	ui->qqApply->setEnabled(selectedPointCount>1);

	if (selectedPointCount!=0)
	{
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(App::mainWindow->editModeContainer->getEditModeBufferSize()-1);
		float bInt0,bInt1;
		it->getBezierFactors(bInt0,bInt1);
		ui->qqFactor1->setText(tt::getFString(false,bInt0,3).c_str());
		ui->qqFactor2->setText(tt::getFString(false,bInt1,3).c_str());
		ui->qqPointCount->setText(tt::getIString(false,it->getBezierPointCount()).c_str());
		ui->qqVirtualDistance->setText(tt::getEString(false,it->getOnSpotDistance(),3).c_str());
		ui->qqAuxFlags->setText(tt::getIString(false,it->getAuxFlags()).c_str());
		float auxChannels[4];
		it->getAuxChannels(auxChannels);
		ui->qqAuxChannel1->setText(tt::getEString(false,auxChannels[0],3).c_str());
		ui->qqAuxChannel2->setText(tt::getEString(false,auxChannels[1],3).c_str());
		ui->qqAuxChannel3->setText(tt::getEString(false,auxChannels[2],3).c_str());
		ui->qqAuxChannel4->setText(tt::getEString(false,auxChannels[3],3).c_str());
	}
	else
	{
		ui->qqFactor1->setText("");
		ui->qqFactor2->setText("");
		ui->qqPointCount->setText("");
		ui->qqVirtualDistance->setText("");
		ui->qqAuxFlags->setText("");
		ui->qqAuxChannel1->setText("");
		ui->qqAuxChannel2->setText("");
		ui->qqAuxChannel3->setText("");
		ui->qqAuxChannel4->setText("");
	}
}

CPathCont* CQDlgPathEdit::getPathCont()
{
	CPathCont* pathCont=NULL;
	if (App::getEditModeType()==PATH_EDIT_MODE)
		pathCont=App::mainWindow->editModeContainer->getEditModePathContainer();
	else
	{
		CPath* path=App::ct->objCont->getPath(App::ct->objCont->getLastSelectionID());
		if (path!=NULL)
			pathCont=path->pathContainer;
	}
	return(pathCont);
}

void CQDlgPathEdit::on_qqClosed_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_closed_path);
		refresh();
	}
}

void CQDlgPathEdit::on_qqFlat_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_flat_path);
		refresh();
	}
}

void CQDlgPathEdit::on_qqAutomaticOrientation_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_automatic_orientation);
		refresh();
	}
}

void CQDlgPathEdit::on_qqKeepXup_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CPathCont* pathCont=getPathCont();
		if (pathCont==NULL)
			return;
		pathCont->setAttributes(pathCont->getAttributes()^sim_pathproperty_keep_x_up);
		refresh();
	}
}

void CQDlgPathEdit::on_qqFactor1_editingFinished()
{
	if (!ui->qqFactor1->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		float bInt0,bInt1;
		it->getBezierFactors(bInt0,bInt1);
		bool ok;
		float newVal=ui->qqFactor1->text().toFloat(&ok);
		if (ok)
			it->setBezierFactors(newVal,bInt1);
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqFactor2_editingFinished()
{
	if (!ui->qqFactor2->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		float bInt0,bInt1;
		it->getBezierFactors(bInt0,bInt1);
		bool ok;
		float newVal=ui->qqFactor2->text().toFloat(&ok);
		if (ok)
			it->setBezierFactors(bInt0,newVal);
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqPointCount_editingFinished()
{
	if (!ui->qqPointCount->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		int newVal=ui->qqPointCount->text().toInt(&ok);
		if (ok)
			it->setBezierPointCount(newVal);
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqVirtualDistance_editingFinished()
{
	if (!ui->qqVirtualDistance->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		float newVal=ui->qqVirtualDistance->text().toFloat(&ok);
		if (ok)
			it->setOnSpotDistance(newVal);
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqApply_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount<2)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		float bInt0,bInt1;
		it->getBezierFactors(bInt0,bInt1);
		for (int i=0;i<selectedPointCount-1;i++)
		{
			CSimplePathPoint* it2=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(i);
			it2->setBezierFactors(bInt0,bInt1);
			it2->setMaxRelAbsVelocity(it->getMaxRelAbsVelocity());
			it2->setBezierPointCount(it->getBezierPointCount());
			it2->setOnSpotDistance(it->getOnSpotDistance());
			it2->setAuxFlags(it->getAuxFlags());
			float auxChannels[4];
			it->getAuxChannels(auxChannels);
			it2->setAuxChannels(auxChannels);
		}
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqClearSelection_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		App::mainWindow->editModeContainer->deselectEditModeBuffer();
		refresh();
	}
}

void CQDlgPathEdit::on_qqInvertSelection_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		for (int i=0;i<int(App::mainWindow->editModeContainer->getEditModePathContainer()->getSimplePathPointCount());i++)
			App::mainWindow->editModeContainer->xorAddItemToEditModeBuffer(i,true);
		refresh();
	}
}

void CQDlgPathEdit::on_qqAuxFlags_editingFinished()
{
	if (!ui->qqAuxFlags->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		int newVal=ui->qqAuxFlags->text().toInt(&ok);
		if (ok)
		{
			tt::limitValue(0,65535,newVal);
			it->setAuxFlags(newVal);
		}
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqAuxChannel1_editingFinished()
{
	if (!ui->qqAuxChannel1->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		float newVal=ui->qqAuxChannel1->text().toFloat(&ok);
		if (ok)
		{
			float auxChannels[4];
			it->getAuxChannels(auxChannels);
			auxChannels[0]=newVal;
			it->setAuxChannels(auxChannels);
		}
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqAuxChannel2_editingFinished()
{
	if (!ui->qqAuxChannel2->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		float newVal=ui->qqAuxChannel2->text().toFloat(&ok);
		if (ok)
		{
			float auxChannels[4];
			it->getAuxChannels(auxChannels);
			auxChannels[1]=newVal;
			it->setAuxChannels(auxChannels);
		}
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqAuxChannel3_editingFinished()
{
	if (!ui->qqAuxChannel3->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		float newVal=ui->qqAuxChannel3->text().toFloat(&ok);
		if (ok)
		{
			float auxChannels[4];
			it->getAuxChannels(auxChannels);
			auxChannels[2]=newVal;
			it->setAuxChannels(auxChannels);
		}
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}
}

void CQDlgPathEdit::on_qqAuxChannel4_editingFinished()
{
	if (!ui->qqAuxChannel4->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if ((App::getEditModeType()&PATH_EDIT_MODE)==0)
			return;
		int selectedPointCount=App::mainWindow->editModeContainer->getEditModeBufferSize();
		if (selectedPointCount==0)
			return;
		CSimplePathPoint* it=App::mainWindow->editModeContainer->getPathEditMode()->getSimplePathPoint(selectedPointCount-1);
		bool ok;
		float newVal=ui->qqAuxChannel4->text().toFloat(&ok);
		if (ok)
		{
			float auxChannels[4];
			it->getAuxChannels(auxChannels);
			auxChannels[3]=newVal;
			it->setAuxChannels(auxChannels);
		}
		App::mainWindow->editModeContainer->getEditModePathContainer()->actualizePath();
		refresh();
	}

}

void CQDlgPathEdit::on_qqMakeDummies_clicked()
{	// Following executed by the main simulation thread:
	App::mainWindow->editModeContainer->processCommand(PATH_EDIT_MODE_MAKE_DUMMIES_FROM_PATH_CTRL_POINTS_EMCMD,NULL);
}
