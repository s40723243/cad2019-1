// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2016 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.3.0 on February 19th 2016

#include "vrepMainHeader.h"
#include "qdlgshapes.h"
#include "ui_qdlgshapes.h"
#include "Tt.h"
#include "GV.h"
#include "qdlgmaterial.h"
#include "geometric.h"
#include "qdlgtextures.h"
#include "qdlggeometry.h"
#include "qdlgshapedyn.h"
#include "VFileDialog.h"
#include "App.h"
#include "imgLoaderSaver.h"
#include "v_repStrings.h"
#include "VMessageBox.h"

CQDlgShapes::CQDlgShapes(QWidget *parent) :
	CDlgEx(parent),
    ui(new Ui::CQDlgShapes)
{
    ui->setupUi(this);
}

CQDlgShapes::~CQDlgShapes()
{
    delete ui;
}

void CQDlgShapes::cancelEvent()
{
	// we override this cancel event. The container window should close, not this one!!
	App::mainWindow->dlgCont->close(OBJECT_DLG);
}

void CQDlgShapes::refresh()
{
	bool sel=App::ct->objCont->isLastSelectionAShape();
	bool ssel=App::ct->objCont->isLastSelectionASimpleShape();
	int sc=App::ct->objCont->getShapeNumberInSelection();
	int ssc=App::ct->objCont->getSimpleShapeNumberInSelection();
	bool snr=App::ct->simulation->isSimulationStopped();
	bool compoundShapeDisplay=(sel&&(!ssel));
	CShape* it=NULL;
	if (sel)
	{
		it=App::ct->objCont->getShape(App::ct->objCont->getLastSelectionID());
	}

	ui->qqEditMultishape->setEnabled(compoundShapeDisplay&&snr);
	ui->qqEditMultishape->setVisible(compoundShapeDisplay);
	ui->qqColorGroup->setVisible(!compoundShapeDisplay);
	ui->qqOtherPropGroup->setVisible(!compoundShapeDisplay);
	ui->qqApplyColors->setVisible(!compoundShapeDisplay);
	ui->qqApplyMain->setVisible(!compoundShapeDisplay);

	ui->qqShadingAngle->setEnabled(ssel);
	ui->qqEdgesAngle->setEnabled(ssel);
	ui->qqBackfaceCulling->setEnabled(ssel);
	ui->qqWireframe->setEnabled(ssel);
	ui->qqShowEdges->setEnabled(ssel);
	ui->qqHiddenBorder->setEnabled(ssel);

	ui->qqApplyColors->setEnabled(ssel&&(ssc>1));
	ui->qqAdjustOutsideColor->setEnabled(ssel);
	ui->qqInvertFaces->setEnabled(sel);

	ui->qqGeometry->setEnabled(sel&&snr);
	ui->qqTexture->setEnabled(ssel&snr);
	ui->qqDirtTexture->setEnabled((sc>0)&&snr);
	ui->qqClearTextures->setEnabled((sc>0)&&snr);

	ui->qqApplyMain->setEnabled(sel&&(sc>1));

	ui->qqEditDynamics->setEnabled(sel);
	ui->qqEditDynamics->setChecked(CQDlgShapeDyn::showDynamicWindow);


	if (ssel)
	{
		ui->qqShadingAngle->setText(tt::getAngleFString(false,((CGeometric*)it->geomData->geomInfo)->getGouraudShadingAngle(),1).c_str());
		ui->qqEdgesAngle->setText(tt::getAngleFString(false,((CGeometric*)it->geomData->geomInfo)->getEdgeThresholdAngle(),1).c_str());
		ui->qqBackfaceCulling->setChecked(((CGeometric*)it->geomData->geomInfo)->getCulling());
		ui->qqWireframe->setChecked(((CGeometric*)it->geomData->geomInfo)->getWireframe());
		ui->qqShowEdges->setChecked(((CGeometric*)it->geomData->geomInfo)->getVisibleEdges());
		ui->qqHiddenBorder->setChecked(((CGeometric*)it->geomData->geomInfo)->getHideEdgeBorders());
	}
	else
	{
		ui->qqShadingAngle->setText("");
		ui->qqEdgesAngle->setText("");
		ui->qqBackfaceCulling->setChecked(false);
		ui->qqWireframe->setChecked(false);
		ui->qqShowEdges->setChecked(false);
		ui->qqHiddenBorder->setChecked(false);
	}
}

void CQDlgShapes::on_qqBackfaceCulling_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		it->setCulling(!it->getCulling());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgShapes::on_qqWireframe_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		it->setShapeWireframe(!it->getShapeWireframe());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgShapes::on_qqInvertFaces_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		it->geomData->invertFrontBack();
		App::setRefreshHierarchyViewFlag();
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
	}
}

void CQDlgShapes::on_qqShowEdges_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		it->setVisibleEdges(!it->getVisibleEdges());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgShapes::on_qqShadingAngle_editingFinished()
{
	if (!ui->qqShadingAngle->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* shape=(CShape*)App::ct->objCont->getLastSelection();
		bool ok;
		float newVal=ui->qqShadingAngle->text().toFloat(&ok);
		if (ok)
		{
			((CGeometric*)shape->geomData->geomInfo)->setGouraudShadingAngle(gv::userToRad*newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgShapes::on_qqApplyMain_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		if (App::ct->objCont->getSimpleShapeNumberInSelection()<2)
			return;
		CShape* last=(CShape*)App::ct->objCont->getLastSelection();
		for (int i=0;i<App::ct->objCont->getSelSize()-1;i++)
		{
			CShape* it=App::ct->objCont->getShape(App::ct->objCont->getSelID(i));
			if (it!=NULL)
			{
				if ( (!it->isCompound())&&(!last->isCompound()) )
				{
					((CGeometric*)it->geomData->geomInfo)->setVisibleEdges(((CGeometric*)last->geomData->geomInfo)->getVisibleEdges());
					((CGeometric*)it->geomData->geomInfo)->setCulling(((CGeometric*)last->geomData->geomInfo)->getCulling());
					((CGeometric*)it->geomData->geomInfo)->setInsideAndOutsideFacesSameColor_DEPRECATED(((CGeometric*)last->geomData->geomInfo)->getInsideAndOutsideFacesSameColor_DEPRECATED());
					((CGeometric*)it->geomData->geomInfo)->setEdgeWidth_DEPRECATED(((CGeometric*)last->geomData->geomInfo)->getEdgeWidth_DEPRECATED());
					((CGeometric*)it->geomData->geomInfo)->setWireframe(((CGeometric*)last->geomData->geomInfo)->getWireframe());
					((CGeometric*)it->geomData->geomInfo)->setGouraudShadingAngle(((CGeometric*)last->geomData->geomInfo)->getGouraudShadingAngle());
					((CGeometric*)it->geomData->geomInfo)->setEdgeThresholdAngle(((CGeometric*)last->geomData->geomInfo)->getEdgeThresholdAngle());
					((CGeometric*)it->geomData->geomInfo)->setHideEdgeBorders(((CGeometric*)last->geomData->geomInfo)->getHideEdgeBorders());
					((CGeometric*)it->geomData->geomInfo)->setDisplayInverted_DEPRECATED(((CGeometric*)last->geomData->geomInfo)->getDisplayInverted_DEPRECATED());

					POST_SCENE_CHANGED_START_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
				}
			}
		}
		POST_SCENE_CHANGED_END_ANNOUNCEMENT(); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgShapes::on_qqEditDynamics_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		CQDlgShapeDyn::showDynamicWindow=!CQDlgShapeDyn::showDynamicWindow;
		if (App::mainWindow->dlgCont->isVisible(SHAPE_DYN_DLG)!=CQDlgShapeDyn::showDynamicWindow)
			App::mainWindow->dlgCont->toggle(SHAPE_DYN_DLG);
	}
}

void CQDlgShapes::on_qqAdjustOutsideColor_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		int identification[4]={it->getLifeID(),0,it->getID(),-1};
		CQDlgMaterial::displayMaterialDlg(identification,&((CGeometric*)it->geomData->geomInfo)->color,App::mainWindow,true,true,true,true,true,true,true,true,true);
	}
}

void CQDlgShapes::on_qqApplyColors_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		if (App::ct->objCont->getSimpleShapeNumberInSelection()<2)
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		for (int i=0;i<App::ct->objCont->getSelSize()-1;i++)
		{
			CShape* it2=App::ct->objCont->getShape(App::ct->objCont->getSelID(i));
			if (it2!=NULL)
			{
				if ( (!it->isCompound())&&(!it2->isCompound()) )
				{
					((CGeometric*)it->geomData->geomInfo)->color.copyYourselfInto(&((CGeometric*)it2->geomData->geomInfo)->color);
					((CGeometric*)it->geomData->geomInfo)->insideColor_DEPRECATED.copyYourselfInto(&((CGeometric*)it2->geomData->geomInfo)->insideColor_DEPRECATED);
					((CGeometric*)it->geomData->geomInfo)->edgeColor_DEPRECATED.copyYourselfInto(&((CGeometric*)it2->geomData->geomInfo)->edgeColor_DEPRECATED);
					it2->actualizeContainsTransparentComponent();
					POST_SCENE_CHANGED_START_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
				}
			}
		}
		POST_SCENE_CHANGED_END_ANNOUNCEMENT(); // **************** UNDO THINGY ****************
	}
}

void CQDlgShapes::on_qqTexture_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		int identification[4]={it->getLifeID(),0,it->getID(),-1};
		CQDlgTextures::display(identification,App::mainWindow);
	}
}

void CQDlgShapes::on_qqGeometry_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionAShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		int identification[3]={it->getLifeID(),0,it->getID()};
		CQDlgGeometry::display(identification,App::mainWindow);
	}
}

void CQDlgShapes::on_qqDirtTexture_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		// 1. Remove existing textures:
		std::vector<CShape*> shapeList;
		for (int i=0;i<App::ct->objCont->getSelSize();i++)
		{
			CShape* shape=App::ct->objCont->getShape(App::ct->objCont->getSelID(i));
			if (shape!=NULL)
			{
				shapeList.push_back(shape);
				std::vector<CGeometric*> components;
				shape->geomData->geomInfo->getAllShapeComponentsCumulative(components);
				for (int j=0;j<int(components.size());j++)
				{
					bool useTexCoords=false;
					CTextureProperty* tp=components[j]->getTextureProperty();
					if (tp!=NULL)
					{
						// Keep the text. coords if simple shape:
						if (!shape->isCompound())
						{
							std::vector<float>* tc=tp->getFixedTextureCoordinates();
							if (tc!=NULL)
							{
								useTexCoords=true;
								((CGeometric*)shape->geomData->geomInfo)->textureCoords_notCopiedNorSerialized.assign(tc->begin(),tc->end());
							}
						}

						App::ct->textureCont->announceGeneralObjectWillBeErased(shape->getID(),-1);
						delete tp;
						components[j]->setTextureProperty(NULL);
					}
					if (!useTexCoords)
						components[j]->textureCoords_notCopiedNorSerialized.clear(); // discard existing texture coordinates
				}
			}
		}

		// 2. Load and apply the "dirt" texture:
		if (shapeList.size()!=0)
		{

		std::string tst(App::directories->textureDirectory);
		std::string filenameAndPath=App::uiThread->getOpenFileName(this,0,"Loading texture...",tst,"",true,"Image files","tga","jpg","jpeg","png","gif","bmp","tiff");
		if (filenameAndPath.length()!=0)
		{
			if (VFile::doesFileExist(filenameAndPath))
			{
				App::directories->textureDirectory=App::directories->getPathFromFull(filenameAndPath);
				int resX,resY,n;
				unsigned char* data=CImageLoaderSaver::load(filenameAndPath.c_str(),&resX,&resY,&n,0);
				bool rgba=(n==4);
				if (n<3)
				{
					delete[] data;
					data=NULL;
				}
				if (data==NULL)
					App::uiThread->messageBox_critical(App::mainWindow,strTranslate("Texture"),strTranslate(IDS_TEXTURE_FILE_COULD_NOT_BE_LOADED),VMESSAGEBOX_OKELI);
				else
				{
					CTextureObject* textureObj=new CTextureObject(resX,resY);
					textureObj->setImage(rgba,false,false,data); // keep false,false
					textureObj->setObjectName(App::directories->getNameFromFull(filenameAndPath).c_str());
					delete[] data;

					for (int i=0;i<int(shapeList.size());i++)
					{
						CShape* shape=shapeList[i];
						std::vector<CGeometric*> components;
						shape->geomData->geomInfo->getAllShapeComponentsCumulative(components);
						for (int j=0;j<int(components.size());j++)
						{
							CGeometric* geom=components[j];
							textureObj->addDependentObject(shape->getID(),geom->getUniqueID());
						}
					}

					int textureID=App::ct->textureCont->addObject(textureObj,false); // might erase the textureObj and return a similar object already present!!

					for (int i=0;i<int(shapeList.size());i++)
					{
						CShape* shape=shapeList[i];
						C3Vector bbhs(shape->geomData->getBoundingBoxHalfSizes());
						float s=SIM_MAX(SIM_MAX(bbhs(0),bbhs(1)),bbhs(2))*2.0f;
						std::vector<CGeometric*> components;
						shape->geomData->geomInfo->getAllShapeComponentsCumulative(components);
						for (int j=0;j<int(components.size());j++)
						{
							CGeometric* geom=components[j];
							CTextureProperty* tp=new CTextureProperty(textureID);

							bool useTexCoords=false;
							if (!shape->isCompound())
							{
								if (((CGeometric*)shape->geomData->geomInfo)->textureCoords_notCopiedNorSerialized.size()!=0)
								{
									std::vector<float> wvert;
									std::vector<int> wind;
									((CGeometric*)shape->geomData->geomInfo)->getCumulativeMeshes(wvert,&wind,NULL);
									if (((CGeometric*)shape->geomData->geomInfo)->textureCoords_notCopiedNorSerialized.size()/2==wind.size())
									{ // we have texture coordinate data attached to the shape's geometry (was added during shape import)
										tp->setFixedCoordinates(&((CGeometric*)shape->geomData->geomInfo)->textureCoords_notCopiedNorSerialized);
										((CGeometric*)shape->geomData->geomInfo)->textureCoords_notCopiedNorSerialized.clear();
										useTexCoords=true;
									}
								}
							}
							if (!useTexCoords)
							{
								tp->setRepeatU(true);
								tp->setRepeatV(true);
								tp->setTextureMapMode(sim_texturemap_cube);
								tp->setInterpolateColors(true);
								tp->setApplyMode(0);
								tp->setTextureScaling(s,s);
							}

							geom->setTextureProperty(tp);
						}
					}

				}
			}
		}
		}
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
	}
}

void CQDlgShapes::on_qqClearTextures_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		for (int i=0;i<App::ct->objCont->getSelSize();i++)
		{
			CShape* shape=App::ct->objCont->getShape(App::ct->objCont->getSelID(i));
			if (shape!=NULL)
			{
				std::vector<CGeometric*> components;
				shape->geomData->geomInfo->getAllShapeComponentsCumulative(components);
				for (int j=0;j<int(components.size());j++)
				{
					bool keepTextCoords=false;
					CTextureProperty* tp=components[j]->getTextureProperty();
					if (tp!=NULL)
					{
						// Keep the text. coords if simple shape:
						if (!shape->isCompound())
						{
							std::vector<float>* tc=tp->getFixedTextureCoordinates();
							if (tc!=NULL)
							{
								((CGeometric*)shape->geomData->geomInfo)->textureCoords_notCopiedNorSerialized.assign(tc->begin(),tc->end());
								keepTextCoords=true;
							}
						}
						App::ct->textureCont->announceGeneralObjectWillBeErased(shape->getID(),-1);
						delete tp;
						components[j]->setTextureProperty(NULL);
					}
					if (!keepTextCoords)
						components[j]->textureCoords_notCopiedNorSerialized.clear(); // discard existing texture coordinates
				}
			}
		}
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
	}
}

void CQDlgShapes::on_qqEdgesAngle_editingFinished()
{
	if (!ui->qqEdgesAngle->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* shape=(CShape*)App::ct->objCont->getLastSelection();
		bool ok;
		float newVal=ui->qqEdgesAngle->text().toFloat(&ok);
		if (ok)
		{
			((CGeometric*)shape->geomData->geomInfo)->setEdgeThresholdAngle(gv::userToRad*newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgShapes::on_qqEditMultishape_clicked()
{
	SSimulationThreadCommand cmd;
	cmd.cmdId=SHAPE_EDIT_MODE_START_EMCMD;
	App::appendSimulationThreadCommand(cmd);
}

void CQDlgShapes::on_qqHiddenBorder_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionASimpleShape())
			return;
		CShape* it=(CShape*)App::ct->objCont->getLastSelection();
		it->setHideEdgeBorders(!it->getHideEdgeBorders());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}
