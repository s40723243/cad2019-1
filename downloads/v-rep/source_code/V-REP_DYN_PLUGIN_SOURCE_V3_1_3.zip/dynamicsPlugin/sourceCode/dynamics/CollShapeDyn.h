// This file is part of the DYNAMICS PLUGIN for V-REP
// 
// Copyright 2006-2014 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// The DYNAMICS PLUGIN is licensed under the terms of EITHER:
//   1. DYNAMICS PLUGIN commercial license (contact us for details)
//   2. DYNAMICS PLUGIN educational license (see below)
// 
// DYNAMICS PLUGIN educational license:
// -------------------------------------------------------------------
// The DYNAMICS PLUGIN educational license applies only to EDUCATIONAL
// ENTITIES composed by following people and institutions:
// 
// 1. Hobbyists, students, teachers and professors
// 2. Schools and universities
// 
// EDUCATIONAL ENTITIES do NOT include companies, research institutions,
// non-profit organisations, foundations, etc.
// 
// An EDUCATIONAL ENTITY may use, modify, compile and distribute the
// modified/unmodified DYNAMICS PLUGIN under following conditions:
//  
// 1. Distribution should be free of charge.
// 2. Distribution should be to EDUCATIONAL ENTITIES only.
// 3. Usage should be non-commercial.
// 4. Altered source versions must be plainly marked as such and distributed
//    along with any compiled code.
// 5. When using the DYNAMICS PLUGIN in conjunction with V-REP, the "EDU"
//    watermark in the V-REP scene view should not be removed.
// 6. The origin of the DYNAMICS PLUGIN must not be misrepresented. you must
//    not claim that you wrote the original software.
// 
// THE DYNAMICS PLUGIN IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.1.3 on Sept. 30th 2014

#pragma once
#include "bullet/btBulletDynamicsCommon.h"
#include "ode/ode.h"
#include "dummyClasses.h"
#include <vector>
#include "7Vector.h"


class CCollShapeDyn  
{
public:

	CCollShapeDyn(CDummyGeomProxy* geomData); // Bullet
	CCollShapeDyn(CDummyGeomProxy* geomData,dSpaceID space); // ODE

	virtual ~CCollShapeDyn();

	int getObjectID();
	void setObjectID(int newID);
	void addRigidBodyDependency(int rigidBodyID);
	bool removeRigidBodyDependency(int rigidBodyID);
	bool isRigidBodyDependent(int rigidBodyID);
	C7Vector getLocalInertiaFrame_scaled();
	C7Vector getInverseLocalInertiaFrame_scaled();

	CDummyGeomProxy* getGeomData_nullForNonRespondable();

	dGeomID getOdeGeoms(int index);
	btCollisionShape* getBtCollisionShape();

	void setOdeMeshLastTransform();

protected:	
	int _objectID;
	C7Vector _localInertiaFrame_scaled;
	C7Vector _inverseLocalInertiaFrame_scaled;
	CDummyGeomProxy* _geomData;
	
	// ODE:
	std::vector<dGeomID> _odeGeoms; // if more than 1 element, then it is a compound object
	dTriMeshDataID _trimeshDataID;
	dHeightfieldDataID _odeHeightfieldDataID;
	float* _odeMeshLastTransformThingMatrix;
	unsigned char _odeMeshLastTransformThingIndex;

	// BULLET:
	btTriangleIndexVertexArray* _indexVertexArrays; // for meshes
	std::vector<btCollisionShape*> _compoundChildShapes;
	btCollisionShape* _collisionShape;


	int _physicsEngineType;

	std::vector<int> _rigidBodyDependencies;
	std::vector<float> _meshVertices_scaled;
	std::vector<int> _meshIndices;

	// ODE:
	std::vector<float> _odeHeightfieldData_scaled;
	std::vector<float> _odeConvexPlanes_scaled;
	std::vector<unsigned int> _odeConvexPolygons;
	std::vector<std::vector<float>* > _odeMmeshVertices_scaled;
	std::vector<std::vector<float>* > _odeMconvexPlanes_scaled;
	std::vector<std::vector<unsigned int>* > _odeMconvexPolygons;

};
