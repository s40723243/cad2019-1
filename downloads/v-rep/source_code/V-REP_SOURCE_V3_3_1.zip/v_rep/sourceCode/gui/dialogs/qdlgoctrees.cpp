// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2016 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.3.1 Rev1 on May 17th 2016

#include "vrepMainHeader.h"
#include "qdlgoctrees.h"
#include "ui_qdlgoctrees.h"
#include "tt.h"
#include "gV.h"
#include "qdlgmaterial.h"
#include "app.h"
#include "v_repStrings.h"

CQDlgOctrees::CQDlgOctrees(QWidget *parent) :
	CDlgEx(parent),
	ui(new Ui::CQDlgOctrees)
{
    ui->setupUi(this);
}

CQDlgOctrees::~CQDlgOctrees()
{
    delete ui;
}

void CQDlgOctrees::cancelEvent()
{
	// we override this cancel event. The container window should close, not this one!!
	App::mainWindow->dlgCont->close(OBJECT_DLG);
}

void CQDlgOctrees::refresh()
{
	bool sel=App::ct->objCont->isLastSelectionAnOctree();
	bool bigSel=(App::ct->objCont->getOctreeNumberInSelection()>1);
	bool simStopped=App::ct->simulation->isSimulationStopped();
	int objCnt=App::ct->objCont->getSelSize();
	COctree* it=NULL;
	if (sel)
		it=(COctree*)App::ct->objCont->getLastSelection();

	ui->qqSize->setEnabled(sel&&simStopped);
	ui->qqColor->setEnabled(sel&&simStopped);
	ui->qqShowOctree->setEnabled(sel&&simStopped);
	ui->qqRandomColors->setEnabled(sel&&simStopped);
	ui->qqUsePoints->setEnabled(sel&&simStopped);
	ui->qqPointSize->setEnabled(sel&&simStopped&&it->getUsePointsInsteadOfCubes());
	ui->qqClear->setEnabled(sel&&simStopped);
	ui->qqInsert->setEnabled(sel&&simStopped&&(objCnt>1));
	ui->qqSubtract->setEnabled(sel&&simStopped&&(objCnt>1));
	ui->qqEmissiveColor->setEnabled(sel&&simStopped);
//	ui->qqReconstructCalcStructure->setEnabled(sel&&simStopped);

	if (sel)
	{
		ui->qqSize->setText(tt::getFString(false,it->getCellSize(),4).c_str());
		ui->qqShowOctree->setChecked(it->getShowOctree());
		ui->qqRandomColors->setChecked(it->getUseRandomColors());
		ui->qqCellCount->setText(tt::getIString(false,it->getCubePositions()->size()/3).c_str());
		ui->qqUsePoints->setChecked(it->getUsePointsInsteadOfCubes());
		ui->qqPointSize->setText(tt::getIString(false,it->getPointSize()).c_str());
		ui->qqEmissiveColor->setChecked(it->getColorIsEmissive());
//		ui->qqReconstructCalcStructure->setChecked(!it->getSaveCalculationStructure());
	}
	else
	{
		ui->qqSize->setText("");
		ui->qqShowOctree->setChecked(false);
		ui->qqRandomColors->setChecked(false);
		ui->qqCellCount->setText("");
		ui->qqUsePoints->setChecked(false);
		ui->qqPointSize->setText("");
		ui->qqEmissiveColor->setChecked(false);
//		ui->qqReconstructCalcStructure->setChecked(false);
	}
}

void CQDlgOctrees::on_qqSize_editingFinished()
{
	if (!ui->qqSize->isModified())
		return;
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		bool ok;
		float newVal=ui->qqSize->text().toFloat(&ok);
		if (ok)
		{
			it->setCellSize(newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgOctrees::on_qqColor_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		int identification[4]={it->getLifeID(),0,it->getID(),-1};
		CQDlgColor::display(identification,it->color.colors,App::mainWindow);
//		CQDlgMaterial::displayMaterialDlg(identification,&it->color,App::mainWindow,true,false,false,false,false,false,false,false,false);
	}
}

void CQDlgOctrees::on_qqShowOctree_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		it->setShowOctree(!it->getShowOctree());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgOctrees::on_qqRandomColors_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		it->setUseRandomColors(!it->getUseRandomColors());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgOctrees::on_qqUsePoints_clicked()
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		it->setUsePointsInsteadOfCubes(!it->getUsePointsInsteadOfCubes());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgOctrees::on_qqPointSize_editingFinished()
{
	if (!ui->qqPointSize->isModified())
		return;
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		bool ok;
		int newVal=ui->qqPointSize->text().toInt(&ok);
		if (ok)
		{
			it->setPointSize(newVal);
			POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		}
		refresh();
	}
}

void CQDlgOctrees::on_qqClear_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		it->clear();
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgOctrees::on_qqInsert_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();

//		App::uiThread->showOrHideProgressBar(true,-1,"Inserting object(s) into octree...");
		it->insertSelectedVisibleObjects();
//		App::uiThread->showOrHideProgressBar(false);
		App::ct->objCont->deselectObjects();
		App::ct->objCont->addObjectToSelection(it->getID());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgOctrees::on_qqSubtract_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();

//		App::uiThread->showOrHideProgressBar(true,-1,"Inserting object(s) into octree...");
		it->subtractSelectedVisibleObjects();
//		App::uiThread->showOrHideProgressBar(false);
		App::ct->objCont->deselectObjects();
		App::ct->objCont->addObjectToSelection(it->getID());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}

void CQDlgOctrees::on_qqEmissiveColor_clicked()
{
	IF_UI_EVENT_CAN_WRITE_DATA
	{
		if (!App::ct->objCont->isLastSelectionAnOctree())
			return;
		COctree* it=(COctree*)App::ct->objCont->getLastSelection();
		it->setColorIsEmissive(!it->getColorIsEmissive());
		POST_SCENE_CHANGED_ANNOUNCEMENT(""); // **************** UNDO THINGY ****************
		refresh();
	}
}
