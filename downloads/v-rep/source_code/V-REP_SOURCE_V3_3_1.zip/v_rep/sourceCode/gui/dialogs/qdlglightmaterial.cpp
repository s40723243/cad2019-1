// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2016 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.3.1 Rev1 on May 17th 2016

// Not very elegant. Needs refactoring!!

#include "vrepMainHeader.h"
#include "qdlglightmaterial.h"
#include "ui_qdlglightmaterial.h"
#include "gV.h"
#include "tt.h"
#include "app.h"

CQDlgLightMaterial::CQDlgLightMaterial(QWidget *parent) :
	CDlgEx(parent),
	ui(new Ui::CQDlgLightMaterial)
{
    ui->setupUi(this);
	diffuse=NULL;
	specular=NULL;
	color=NULL;
	_identification[0]=-1;
	_identification[1]=-1;
	_identification[2]=-1;
	_identification[3]=-1;
	isModal=false;
	if (App::mainWindow!=NULL)
		App::mainWindow->dlgCont->close(COLOR_DLG);
}

CQDlgLightMaterial::~CQDlgLightMaterial()
{
    delete ui;
	if (App::mainWindow!=NULL)
		App::mainWindow->dlgCont->close(COLOR_DLG);
}

void CQDlgLightMaterial::refresh()
{
	ui->qqDiffuseAdjust->setEnabled(diffuse!=NULL);
	ui->qqSpecularAdjust->setEnabled(specular!=NULL);
}

bool CQDlgLightMaterial::needsDestruction()
{
	if (!isLinkedDataValid())
		return(true);
	return(CDlgEx::needsDestruction());
}

void CQDlgLightMaterial::_initialize(int identification[4],CVisualParam* it,bool diff,bool spec)
{ // All boolean value are true by default! If a value is true, it can be adjusted
	_identification[0]=identification[0];
	_identification[1]=identification[1];
	_identification[2]=identification[2];
	_identification[3]=identification[3];
	diffuse=it->colors+3;
	specular=it->colors+6;
	if (!diff)
		diffuse=NULL;
	if (!spec)
		specular=NULL;
	refresh();
}

bool CQDlgLightMaterial::isLinkedDataValid()
{
	if (!CLifeControl::isAlive(_identification[0]))
		return(false);
	if (_identification[1]==0)
	{ // we have a 3DObject here
		if (App::ct->objCont!=NULL)
		{
			if (App::ct->objCont->getLastSelectionID()!=_identification[2])
				return(false);
		}
	}
	return(true);
}

void CQDlgLightMaterial::display(int identification[4],CVisualParam* it,QWidget* theParentWindow,bool diff,bool spec)
{ // All boolean value are true by default! If a value is true, it can be adjusted
	if (App::mainWindow==NULL)
		return;
	App::mainWindow->dlgCont->close(LIGHTMATERIAL_DLG);
	App::mainWindow->dlgCont->close(COLOR_DLG);
	if (App::mainWindow->dlgCont->openOrBringToFront(LIGHTMATERIAL_DLG))
	{
		CQDlgLightMaterial* mat=(CQDlgLightMaterial*)App::mainWindow->dlgCont->getDialog(LIGHTMATERIAL_DLG);
		if (mat!=NULL)
			mat->_initialize(identification,it,diff,spec);
	}
}

void CQDlgLightMaterial::colorAdjust(float* col)
{
	IF_UI_EVENT_CAN_READ_DATA
	{
		if (col!=NULL)
		{
			if (!isModal)
			{
				if (isLinkedDataValid())
				{
					if (App::mainWindow->dlgCont->openOrBringToFront(COLOR_DLG))
					{
						CQDlgColor* it=(CQDlgColor*)App::mainWindow->dlgCont->getDialog(COLOR_DLG);
						if (it!=NULL)
							it->initialize(col,_identification);
					}
				}
			}
			else
			{
				CQDlgColor it(this);
				it.initialize(col,_identification);
				it.makeDialogModal();
			}
		}
	}
}

void CQDlgLightMaterial::cancelEvent()
{ // We just hide the dialog and destroy it at next rendering pass
	diffuse=NULL;
	specular=NULL;
	if (((QDialog*)this)->isModal()) // this condition and next line on 31/3/2013: on Linux the dlg couldn't be closed!
		defaultModalDialogEndRoutine(false);
	else
		CDlgEx::cancelEvent();
}

bool CQDlgLightMaterial::doesInstanceSwitchRequireDestruction()
{
	return(true);
}

void CQDlgLightMaterial::on_qqDiffuseAdjust_clicked()
{
	colorAdjust(diffuse);
}

void CQDlgLightMaterial::on_qqSpecularAdjust_clicked()
{
	colorAdjust(specular);
}

