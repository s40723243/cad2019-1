// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2016 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.3.2 on August 29th 2016

#pragma once

#include <QMainWindow>
#include <QToolBar>
#include <QComboBox>
#include <QToolButton>
#include <QSignalMapper>
#include <QSplitter>
#include <QPlainTextEdit>
#include <QMenu>
#include <QAction>
#include <QComboBox>
#include "qvrep_openglwidget.h"
#include "global.h"
#include "dlgCont.h"
#include "customMenuBarItemContainer.h"
#include "simRecorder.h"
#include "VPoint.h"
#include "oglSurface.h"
#include "editModeContainer.h"
#include "scintillaConsoleContainer.h"
#include "scintillaEditorContainer.h"
#include "simThread.h"

enum {FOCUS_ON_PAGE=0,FOCUS_ON_HIERARCHY,FOCUS_ON_SOFT_DIALOG,FOCUS_ON_SCENE_SELECTION_WINDOW,FOCUS_ON_VIEW_SELECTION_WINDOW,FOCUS_ON_PAGE_SELECTION_WINDOW,FOCUS_ON_UNKNOWN_OBJECT,FOCUS_ON_BROWSER};

struct SSceneThumbnail
{
    unsigned char* textureData;
    int textureResolution[2];
};


class CMainWindow : public QMainWindow
{
    Q_OBJECT
public:
    CMainWindow();
    virtual ~CMainWindow();

    void executeCommand(SUIThreadCommand* cmdIn,SUIThreadCommand* cmdOut);
    void initializeWindow();

    bool event(QEvent* event);
    void dragEnterEvent(QDragEnterEvent* dEvent);
    void dropEvent(QDropEvent* dEvent);
    QMenu* createPopupMenu() { return NULL; } // required to avoid having a popup when over the toolbar (and other situations). 4/12/2011

    void refreshDimensions();
    void setWindowDimensions(int x,int y,bool clientSurface,bool maximized);
    void windowResizeEvent(int x,int y);
    bool isFullScreen();
    void setFullScreen(bool f);
    void setOpenGlDisplayEnabled(bool e);
    bool getOpenGlDisplayEnabled();
    void setFocusObject(int f);
    void setCurrentCursor(int cur);

    void flashStatusbar();
    void setFlyModeCameraHandle(int h);
    int getFlyModeCameraHandle();
    void setProxSensorClickSelectDown(int v);
    int getProxSensorClickSelectDown();
    void setProxSensorClickSelectUp(int v);
    int getProxSensorClickSelectUp();

    bool getHasStereo();
    void setStereoDistance(float d);
    float getStereoDistance();
    bool getLeftEye();

    void createDefaultMenuBar();
    void removeDefaultMenuBar();

    int getMouseButtonState();
    void setMouseButtonState(int state);
    void getMouseRenderingPos(int pos[2]);

    int getKeyDownState();
    void setKeyDownState(int state);

    int getMouseMode();
    void setMouseMode(int mm);
    void setDefaultMouseMode();

    void setLightDialogRefreshFlag();
    void setFullDialogRefreshFlag();
    void setDialogRefreshDontPublishFlag();
    void setToolbarRefreshFlag();
    void activateMainWindow();
    void closeDlg(int dlgId);
    void openOrBringDlgToFront(int dlgId);
    bool prepareSceneThumbnail(const SSimulationThreadCommand& command);
    unsigned char* getSceneThumbnail(int instanceIndex,int resolution[2]);

    bool getObjectShiftToggleViaGuiEnabled();
    void setObjectShiftToggleViaGuiEnabled(bool e);
    bool getObjectRotateToggleViaGuiEnabled();
    void setObjectRotateToggleViaGuiEnabled(bool e);
    void setHierarchyToggleViaGuiEnabled(bool e);
    bool getHierarchyToggleViaGuiEnabled();
    void setBrowserToggleViaGuiEnabled(bool e);
    bool getBrowserToggleViaGuiEnabled();
    void setObjPropToggleViaGuiEnabled(bool e);
    bool getObjPropToggleViaGuiEnabled();
    void setCalcModulesToggleViaGuiEnabled(bool e);
    bool getCalcModulesToggleViaGuiEnabled();
    void setPlayViaGuiEnabled(bool e);
    bool getPlayViaGuiEnabled();
    void setPauseViaGuiEnabled(bool e);
    bool getPauseViaGuiEnabled();
    void setStopViaGuiEnabled(bool e);
    bool getStopViaGuiEnabled();

//------------------------
    void uiThread_renderScene(bool bufferMainDisplayStateVariables);
    void uiThread_renderScene_noLock(bool bufferMainDisplayStateVariables);
    void simThread_prepareToRenderScene();
    void refreshDialogs_uiThread();
    void callDialogFunction(const SUIThreadCommand* cmdIn,SUIThreadCommand* cmdOut);
//------------------------

    QSignalMapper* getPopupSignalMapper();
    COpenglWidget* openglWidget;
    QPlainTextEdit* statusBar;

    CDlgCont* dlgCont;
    CCustomMenuBarItemContainer* customMenuBarItemContainer;
    CSimRecorder* simulationRecorder;
    COglSurface* oglSurface;
    CEditModeContainer* editModeContainer;
    CScintillaConsoleContainer* scintillaConsoleContainer;
    CScintillaEditorContainer* scintillaEditorContainer;

    void onLeftMouseButtonDownTT(int xPos,int yPos);
    void onMiddleMouseButtonDownTT(int xPos,int yPos);
    void onRightMouseButtonDownTT(int xPos,int yPos);
    void onLeftMouseButtonDoubleClickTT(int xPos,int yPos);
    void onLeftMouseButtonUpTT(int xPos,int yPos);
    void onMiddleMouseButtonUpTT(int xPos,int yPos);
    void onRightMouseButtonUpTT(int xPos,int yPos);
    void onMouseMoveTT(int xPos,int yPos);
    void onWheelRotateTT(int delta,int xPos,int yPos);

    void onKeyPress(SMouseOrKeyboardOrResizeEvent e);
    void onKeyRelease(SMouseOrKeyboardOrResizeEvent e);

    void simulationAboutToStart();
    void simulationEnded();

    void newInstanceAboutToBeCreated();
    void instanceAboutToBeDestroyed(int currentInstanceIndex);
    void instanceAboutToChange(int newInstanceIndex);

    void closeTemporarilyNonEditModeDialogs();
    void reopenTemporarilyClosedNonEditModeDialogs();
    void closeTemporarilyDialogsForViewSelector();
    void reopenTemporarilyClosedDialogsForViewSelector();
    void closeTemporarilyDialogsForPageSelector();
    void reopenTemporarilyClosedDialogsForPageSelector();
    void closeTemporarilyDialogsForSceneSelector();
    void reopenTemporarilyClosedDialogsForSceneSelector();

private:
    int _renderOpenGlContent_callFromRenderingThreadOnly();
    void _actualizetoolbarButtonState();
    void _dropFilesIntoScene(const std::vector<std::string>& tttFiles,const std::vector<std::string>& ttmFiles,const std::vector<std::string>& ttbFiles);
    void _createDefaultToolBars();
    void _recomputeClientSizeAndPos();
    void _setInitialDimensions(bool maximized);
    void _setClientArea(int x,int y);
    void _resetStatusbarFlashIfNeeded();
    void _closeDialogTemporarilyIfOpened(int dlgID,std::vector<int>& vect);

    QSignalMapper* _signalMapper;
    QSignalMapper* _popupSignalMapper;
    QSplitter* _splitter;

    VMenubar* _menubar;
    VMenu* _fileSystemMenu;
    VMenu* _editSystemMenu;
    VMenu* _addSystemMenu;
    VMenu* _simulationSystemMenu;
    VMenu* _windowSystemMenu;
    VMenu* _addOnSystemMenu;
    VMenu* _helpSystemMenu;
    VMenu* _instancesSystemMenu;

    std::vector<CScintillaEditorContainer*> _scintillaEditorContainerList;
    std::vector<SSceneThumbnail> _sceneThumbnails;

    QToolBar* _toolbar1;
    QToolBar* _toolbar2;
    QAction* _toolbarActionCameraShift;
    QAction* _toolbarActionCameraRotate;
    QAction* _toolbarActionCameraZoom;
    QAction* _toolbarActionCameraAngle;
    QAction* _toolbarActionCameraSizeToScreen;
    QAction* _toolbarActionCameraFly;
    QAction* _toolbarActionObjectShift;
    QAction* _toolbarActionObjectRotate;
    QAction* _toolbarActionClickSelection;
    QAction* _toolbarActionAssemble;
    QAction* _toolbarActionTransferDna;
    QAction* _toolbarActionUndo;
    QAction* _toolbarActionRedo;
    QAction* _toolbarActionDynamicContentVisualization;
    QComboBox* _engineSelectCombo;
    QComboBox* _enginePrecisionCombo;
    QComboBox* _timeStepConfigCombo;
    QAction* _toolbarActionStart;
    QAction* _toolbarActionPause;
    QAction* _toolbarActionStop;
    QAction* _toolbarActionRealTime;
    QAction* _toolbarActionReduceSpeed;
    QAction* _toolbarActionIncreaseSpeed;
    QAction* _toolbarActionThreadedRendering;
    QAction* _toolbarActionToggleVisualization;
    QAction* _toolbarActionPageSelector;
    QAction* _toolbarActionSceneSelector;
    QAction* _toolbarActionSimulationSettings;
    QAction* _toolbarActionObjectProperties;
    QAction* _toolbarActionCalculationModules;
    QAction* _toolbarActionCollections;
    QAction* _toolbarActionScripts;
    QAction* _toolbarActionShapeEdition;
    QAction* _toolbarAction2dElements;
    QAction* _toolbarActionPathEdition;
    QAction* _toolbarActionSelection;
    QAction* _toolbarActionModelBrowser;
    QAction* _toolbarActionSceneHierarchy;
    QAction* _toolbarActionLayers;
    QAction* _toolbarActionAviRecorder;
    QAction* _toolbarActionUserSettings;

    std::vector<int> _dialogsClosedTemporarily_editModes;
    std::vector<int> _dialogsClosedTemporarily_viewSelector;
    std::vector<int> _dialogsClosedTemporarily_pageSelector;
    std::vector<int> _dialogsClosedTemporarily_sceneSelector;

    int _mouseButtonsState; // 1=left, 2=wheel activity, 4=right, 8=middle wheel down, 16=last mouse down was left and not ctrl pressed
    int _keyDownState; // 1=ctrl, 2=shift, 4=up, 8=down, 16=left, 32=right
    int _renderingTimeInMs;
    float _fps;
    bool _fullscreen;
    bool _hasStereo;
    float _stereoDistance;
    bool _leftEye;
    int _statusbarFlashTime;
    VPoint _mouseRenderingPos;
    VPoint _clientArea;
    int _focusObject;
    int _currentCursor;
    int _mouseWheelEventTime;
    bool _openGlDisplayEnabled;
    int _mouseMode;
    int _flyModeCameraHandle;
    int _proxSensorClickSelectDown;
    int _proxSensorClickSelectUp;
    SSimulationThreadCommand _prepareSceneThumbnailCmd;


    bool _lightDialogRefreshFlag;
    bool _fullDialogRefreshFlag;
    bool _dialogRefreshDontPublishFlag;
    bool _toolbarRefreshFlag;

    bool _toolbarButtonObjectShiftEnabled;
    bool _toolbarButtonObjectRotateEnabled;
    bool _toolbarButtonHierarchyEnabled;
    bool _toolbarButtonBrowserEnabled;
    bool _toolbarButtonPlayEnabled;
    bool _toolbarButtonPauseEnabled;
    bool _toolbarButtonStopEnabled;
    bool _toolbarButtonObjPropEnabled;
    bool _toolbarButtonCalcModulesEnabled;

public slots:
    void _engineSelectedViaToolbar(int index);
    void _enginePrecisionViaToolbar(int index);
    void _timeStepConfigViaToolbar(int index);

    void _vrepPopupMessageHandler(int id);
    void _vrepMessageHandler(int id);

    void _aboutToShowFileSystemMenu();
    void _aboutToShowEditSystemMenu();
    void _aboutToShowAddSystemMenu();
    void _aboutToShowSimulationSystemMenu();
    void _aboutToShowWindowSystemMenu();
    void _aboutToShowAddOnSystemMenu();
    void _aboutToShowHelpSystemMenu();
    void _aboutToShowInstancesSystemMenu();
    void _aboutToShowCustomMenu();

    void splitterMoved(int pos,int index);  
};
