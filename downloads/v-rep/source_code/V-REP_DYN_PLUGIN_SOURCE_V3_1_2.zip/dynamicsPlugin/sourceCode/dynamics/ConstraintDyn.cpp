// This file is part of the DYNAMICS PLUGIN for V-REP
// 
// Copyright 2006-2014 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// The DYNAMICS PLUGIN is licensed under the terms of EITHER:
//   1. DYNAMICS PLUGIN commercial license (contact us for details)
//   2. DYNAMICS PLUGIN educational license (see below)
// 
// DYNAMICS PLUGIN educational license:
// -------------------------------------------------------------------
// The DYNAMICS PLUGIN educational license applies only to EDUCATIONAL
// ENTITIES composed by following people and institutions:
// 
// 1. Hobbyists, students, teachers and professors
// 2. Schools and universities
// 
// EDUCATIONAL ENTITIES do NOT include companies, research institutions,
// non-profit organisations, foundations, etc.
// 
// An EDUCATIONAL ENTITY may use, modify, compile and distribute the
// modified/unmodified DYNAMICS PLUGIN under following conditions:
//  
// 1. Distribution should be free of charge.
// 2. Distribution should be to EDUCATIONAL ENTITIES only.
// 3. Usage should be non-commercial.
// 4. Altered source versions must be plainly marked as such and distributed
//    along with any compiled code.
// 5. When using the DYNAMICS PLUGIN in conjunction with V-REP, the "EDU"
//    watermark in the V-REP scene view should not be removed.
// 6. The origin of the DYNAMICS PLUGIN must not be misrepresented. you must
//    not claim that you wrote the original software.
// 
// THE DYNAMICS PLUGIN IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.1.2 on June 16th 2014

#include "ConstraintDyn.h"
#include "dynInterface.h"
#include "v_repLib.h"


CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyJoint* joint,dWorldID odeWorldID)
{
	_physicsEngineType=sim_physics_ode;
	_odeJointFeedbackStructure=NULL; // Only used with ODE force sensors or joints (1/6/2011)
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=-1; // not used (non-looped case)
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=-1; // not used (non-looped case)
	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_jointIsCyclic=!_simGetJointPositionInterval(joint,&_nonCyclicRevoluteJointPositionMinimum,&_nonCyclicRevoluteJointPositionRange);
	_dummyID=-1;
	_forceSensorID=-1;
	_constraintID=-1;
	_jointID=_simGetObjectID(joint);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;

	// Following 4 lines are important when a joint is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(joint,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	C7Vector tmpTr1,tmpTr2;
	_simGetObjectCumulativeTransformation(childShape,tmpTr1.X.data,tmpTr1.Q.data,false);
	_simGetObjectCumulativeTransformation(joint,tmpTr2.X.data,tmpTr2.Q.data,false);
	_secondInitialLocalTransform=tmpTr1.getInverse()*tmpTr2;

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr,jtr2;
	_simGetObjectCumulativeTransformation(joint,jtr.X.data,jtr.Q.data,true);
	_simGetObjectCumulativeTransformation(joint,jtr2.X.data,jtr2.Q.data,false);

	C3X3Matrix m;
	m.buildYRotation(piValue);
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{ // in ODE the rotation direction is the negative z-axis (not like V-REP the z-axis)
		jtr.Q=jtr.Q*m.getQuaternion();
		jtr2.Q=jtr2.Q*m.getQuaternion();
	}
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{ // in ODE the moving direction is the negative z-axis (not like V-REP the z-axis)
		C3X3Matrix jointOffsetThing;
		jointOffsetThing.setIdentity();
		if (_simGetJointPositionInterval(joint,NULL,NULL))
		{ // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
			_nonCyclicRevoluteJointPositionOffset=-_nonCyclicRevoluteJointPositionMinimum-_nonCyclicRevoluteJointPositionRange*0.5f;
			jointOffsetThing.buildZRotation(_nonCyclicRevoluteJointPositionOffset);
			_jointPosAlt=_simGetJointPosition(joint)+_nonCyclicRevoluteJointPositionOffset;
		}
		jtr.Q=jtr.Q*m.getQuaternion(); 
		jtr2.Q=jtr2.Q*jointOffsetThing.getQuaternion()*m.getQuaternion(); 
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

//	if ((parentBody->isBodyKinematic())
	{ // this is a dynamic object
		dBodySetAutoDisableFlag(parentBody->getOdeRigidBody(),0);
		dBodyEnable(parentBody->getOdeRigidBody());
	}
	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

//	if ((childBody->isBodyKinematic())
	{ // this is a dynamic object
		dBodySetAutoDisableFlag(childBody->getOdeRigidBody(),0);
		dBodyEnable(childBody->getOdeRigidBody());
	}
	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();


	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING

	jtr.X*=linScaling; // ********** SCALING
	jtr2.X*=linScaling; // ********** SCALING
	C3X3Matrix jtrm(jtr.Q);
	float stopERP,stopCFM,bounce,fudge,normalCFM;
	_simGetJointOdeParameters(joint,&stopERP,&stopCFM,&bounce,&fudge,&normalCFM);
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{
		_odeConstraint=dJointCreateHinge(odeWorldID,0);
		dJointSetHingeParam(_odeConstraint,dParamFudgeFactor,fudge);
		dJointSetHingeParam(_odeConstraint,dParamBounce,bounce);
		dJointSetHingeParam(_odeConstraint,dParamCFM,normalCFM);
		dJointSetHingeParam(_odeConstraint,dParamStopERP,stopERP);
		dJointSetHingeParam(_odeConstraint,dParamStopCFM,stopCFM);

		// Set the configuration of the child as if the joint was at 0 position:
		dBodyID cb=childBody->getOdeRigidBody();
		C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
		C7Vector alpha(jtr2.getInverse()*cb_a);
		C7Vector cb_b(jtr*alpha);
		dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
		dBodySetQuaternion(cb,cb_b.Q.data);


		// Attach the joint to the 2 bodies
		dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
		dJointSetHingeAnchor(_odeConstraint,jtr.X(0),jtr.X(1),jtr.X(2));
		dJointSetHingeAxis(_odeConstraint,jtrm.axis[2](0),jtrm.axis[2](1),jtrm.axis[2](2));

		// Reset the configuration of the child as it is now:
		dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
		dBodySetQuaternion(cb,cb_a.Q.data);

		// New since 1/6/2011:
		_odeJointFeedbackStructure=new dJointFeedback;
		dJointSetFeedback(_odeConstraint,_odeJointFeedbackStructure);
	}
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{
		_odeConstraint=dJointCreateSlider(odeWorldID,0);
		dJointSetSliderParam(_odeConstraint,dParamFudgeFactor,fudge);
		dJointSetSliderParam(_odeConstraint,dParamBounce,bounce);
		dJointSetSliderParam(_odeConstraint,dParamCFM,normalCFM);
		dJointSetSliderParam(_odeConstraint,dParamStopERP,stopERP);
		dJointSetSliderParam(_odeConstraint,dParamStopCFM,stopCFM);

		// Set the configuration of the child as if the joint was at 0 position:
		dBodyID cb=childBody->getOdeRigidBody();
		C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
		C7Vector alpha(jtr2.getInverse()*cb_a);
		C7Vector cb_b(jtr*alpha);
		dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
		dBodySetQuaternion(cb,cb_b.Q.data);

		// Attach the joint to the 2 bodies
		dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
		dJointSetSliderAxis(_odeConstraint,jtrm.axis[2](0),jtrm.axis[2](1),jtrm.axis[2](2));

		// Reset the configuration of the child as it is now:
		dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
		dBodySetQuaternion(cb,cb_a.Q.data);

		// New since 1/6/2011:
		_odeJointFeedbackStructure=new dJointFeedback;
		dJointSetFeedback(_odeConstraint,_odeJointFeedbackStructure);
	}
	if (_simGetJointType(joint)==sim_joint_spherical_subtype)
	{
		_odeConstraint=dJointCreateBall(odeWorldID,0);
		dJointSetBallParam(_odeConstraint,dParamFudgeFactor,fudge);
		dJointSetBallParam(_odeConstraint,dParamBounce,bounce);
		dJointSetBallParam(_odeConstraint,dParamCFM,normalCFM);
		dJointSetBallParam(_odeConstraint,dParamStopERP,stopERP);
		dJointSetBallParam(_odeConstraint,dParamStopCFM,stopCFM);

		// Set the configuration of the child as if the joint was at 0 position:
		dBodyID cb=childBody->getOdeRigidBody();
		C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
		C7Vector alpha(jtr2.getInverse()*cb_a);
		C7Vector cb_b(jtr*alpha);
		dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
		dBodySetQuaternion(cb,cb_b.Q.data);

		// Attach the joint to the 2 bodies
		dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
		dJointSetBallAnchor(_odeConstraint,jtr.X(0),jtr.X(1),jtr.X(2));

		// Reset the configuration of the child as it is now:
		dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
		dBodySetQuaternion(cb,cb_a.Q.data);

		_odeJointFeedbackStructure=NULL;
	}
	handleMotorControl(joint,0,0);
}




CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyJoint* joint,btDiscreteDynamicsWorld* bulletWorld)
{
	_physicsEngineType=sim_physics_bullet;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=-1; // not used (non-looped case)
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=-1; // not used (non-looped case)
	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_jointIsCyclic=!_simGetJointPositionInterval(joint,&_nonCyclicRevoluteJointPositionMinimum,&_nonCyclicRevoluteJointPositionRange);
	_dummyID=-1;
	_forceSensorID=-1;
	_constraintID=-1;
	_jointID=_simGetObjectID(joint);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;

	// Following 4 lines are important when a joint is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(joint,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	C7Vector tmpTr1;
	C7Vector tmpTr2;
	_simGetObjectCumulativeTransformation(childShape,tmpTr1.X.data,tmpTr1.Q.data,false);
	_simGetObjectCumulativeTransformation(joint,tmpTr2.X.data,tmpTr2.Q.data,false);
	_secondInitialLocalTransform=tmpTr1.getInverse()*tmpTr2;

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr,jtr2;
	_simGetObjectCumulativeTransformation(joint,jtr.X.data,jtr.Q.data,true);
	_simGetObjectCumulativeTransformation(joint,jtr2.X.data,jtr2.Q.data,false);

	C3X3Matrix m;
	m.setIdentity();
	m.buildYRotation(1.5707963267f);
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{ // in Bullet the moving direction is the x-axis (not like V-REP the z-axis)
		jtr.Q=jtr.Q*m.getQuaternion();
		jtr2.Q=jtr2.Q*m.getQuaternion();
	}
	m.setIdentity();
	m.buildYRotation(piValue);
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{ // in Bullet the moving direction is the negative z-axis (not like V-REP the z-axis)
		C3X3Matrix jointOffsetThing;
		jointOffsetThing.setIdentity();
		if (_simGetJointPositionInterval(joint,NULL,NULL))
		{ // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
			_nonCyclicRevoluteJointPositionOffset=-_nonCyclicRevoluteJointPositionMinimum-_nonCyclicRevoluteJointPositionRange*0.5f;
			jointOffsetThing.buildZRotation(_nonCyclicRevoluteJointPositionOffset);
			_jointPosAlt=_simGetJointPosition(joint)+_nonCyclicRevoluteJointPositionOffset;
		}
		jtr.Q=jtr.Q*m.getQuaternion(); 
		jtr2.Q=jtr2.Q*jointOffsetThing.getQuaternion()*m.getQuaternion(); 
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	if ((parentBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		parentBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		parentBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

	if ((childBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		childBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		childBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING
	float stopERP,stopCFM,normalCFM;
	_simGetJointBulletParameters(joint,&stopERP,&stopCFM,&normalCFM);
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{
		btHingeConstraint* hinge;
		btTransform jtrA;
		jtrA.setOrigin(btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)));
		jtrA.setRotation(btQuaternion(jtrRelToBodyA.Q(1),jtrRelToBodyA.Q(2),jtrRelToBodyA.Q(3),jtrRelToBodyA.Q(0)));
		btTransform jtrB;
		jtrB.setOrigin(btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
		jtrB.setRotation(btQuaternion(jtrRelToBodyB.Q(1),jtrRelToBodyB.Q(2),jtrRelToBodyB.Q(3),jtrRelToBodyB.Q(0)));
		hinge=new btHingeConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),jtrA,jtrB,false);
		_constraint=hinge;
		// You have to modify the btHingeConstraint code and remove the -pi;+pi limitation in the setLimit routine!!!

		hinge->setParam(BT_CONSTRAINT_STOP_ERP,stopERP);
		hinge->setParam(BT_CONSTRAINT_STOP_CFM,stopCFM);
		hinge->setParam(BT_CONSTRAINT_CFM,normalCFM);
	}
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{
		btSliderConstraint* slider;

		btTransform jtrA;
		jtrA.setOrigin(btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)));
		jtrA.setRotation(btQuaternion(jtrRelToBodyA.Q(1),jtrRelToBodyA.Q(2),jtrRelToBodyA.Q(3),jtrRelToBodyA.Q(0)));

		btTransform jtrB;
		jtrB.setOrigin(btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
		jtrB.setRotation(btQuaternion(jtrRelToBodyB.Q(1),jtrRelToBodyB.Q(2),jtrRelToBodyB.Q(3),jtrRelToBodyB.Q(0)));

		slider=new btSliderConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),jtrA,jtrB,false);
		_constraint=slider;

		slider->setParam(BT_CONSTRAINT_STOP_ERP,stopERP);
		slider->setParam(BT_CONSTRAINT_STOP_CFM,stopCFM);
		slider->setParam(BT_CONSTRAINT_CFM,normalCFM);
	}
	if (_simGetJointType(joint)==sim_joint_spherical_subtype)
	{
		btPoint2PointConstraint* ballSocket;
		ballSocket=new btPoint2PointConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)),btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
		_constraint=ballSocket;

		ballSocket->setParam(BT_CONSTRAINT_STOP_ERP,stopERP);
		ballSocket->setParam(BT_CONSTRAINT_STOP_CFM,stopCFM);
		ballSocket->setParam(BT_CONSTRAINT_CFM,normalCFM);
	}
	bulletWorld->addConstraint(_constraint);
	handleMotorControl(joint,0,0);
}






CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyJoint* joint,CDummyDummy* loopClosureDummyA,CDummyDummy* loopClosureDummyB,dWorldID odeWorldID)
{
	_physicsEngineType=sim_physics_ode;
	_odeJointFeedbackStructure=NULL; // Only used with ODE force sensors or joints (1/6/2011)
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=_simGetObjectID(loopClosureDummyA);
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=_simGetObjectID(loopClosureDummyB);

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_jointIsCyclic=!_simGetJointPositionInterval(joint,&_nonCyclicRevoluteJointPositionMinimum,&_nonCyclicRevoluteJointPositionRange);
	_dummyID=-1;
	_forceSensorID=-1;
	_constraintID=-1;
	_jointID=_simGetObjectID(joint);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;

	// Following 4 lines are important when a joint is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(joint,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);

	_simGetObjectLocalTransformation(loopClosureDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data,false);
	_simGetObjectLocalTransformation(loopClosureDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data,false);


	// Following is DIFFERENT from the regular situation (non-looped):
	_simGetObjectLocalTransformation(loopClosureDummyB,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data,false);

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr;
	_simGetObjectCumulativeTransformation(joint,jtr.X.data,jtr.Q.data,true);

	// Following is DIFFERENT from the regular situation (non-looped):
	C7Vector tmpTr1;
	_simGetObjectCumulativeTransformation(loopClosureDummyB,tmpTr1.X.data,tmpTr1.Q.data,false);
	C7Vector jtr2(tmpTr1*_linkedDummyAInitialLocalTransform.getInverse());


	C3X3Matrix m;
	m.setIdentity();
	m.buildYRotation(piValue);
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{ // in ODE the rotation direction is the negative z-axis (not like V-REP the z-axis)
		jtr.Q=jtr.Q*m.getQuaternion();
		jtr2.Q=jtr2.Q*m.getQuaternion();
	}
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{ // in ODE the moving direction is the negative z-axis (not like V-REP the z-axis)
		C3X3Matrix jointOffsetThing;
		jointOffsetThing.setIdentity();
		if (_simGetJointPositionInterval(joint,NULL,NULL))
		{ // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
			_nonCyclicRevoluteJointPositionOffset=-_nonCyclicRevoluteJointPositionMinimum-_nonCyclicRevoluteJointPositionRange*0.5f;
			jointOffsetThing.buildZRotation(_nonCyclicRevoluteJointPositionOffset);
			_jointPosAlt=_simGetJointPosition(joint)+_nonCyclicRevoluteJointPositionOffset;
		}
		jtr.Q=jtr.Q*m.getQuaternion(); 
		jtr2.Q=jtr2.Q*jointOffsetThing.getQuaternion()*m.getQuaternion(); 
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

//	if ((parentBody->isBodyKinematic())
	{ // this is a dynamic object
		dBodySetAutoDisableFlag(parentBody->getOdeRigidBody(),0);
		dBodyEnable(parentBody->getOdeRigidBody());
	}
	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

//	if ((childBody->isBodyKinematic())
	{ // this is a dynamic object
		dBodySetAutoDisableFlag(childBody->getOdeRigidBody(),0);
		dBodyEnable(childBody->getOdeRigidBody());
	}
	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING

	jtr.X*=linScaling; // ********** SCALING
	jtr2.X*=linScaling; // ********** SCALING
	C3X3Matrix jtrm(jtr.Q);
	float stopERP,stopCFM,bounce,fudge,normalCFM;
	_simGetJointOdeParameters(joint,&stopERP,&stopCFM,&bounce,&fudge,&normalCFM);

	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{
		_odeConstraint=dJointCreateHinge(odeWorldID,0);
		dJointSetHingeParam(_odeConstraint,dParamFudgeFactor,fudge);
		dJointSetHingeParam(_odeConstraint,dParamBounce,bounce);
		dJointSetHingeParam(_odeConstraint,dParamCFM,normalCFM);
		dJointSetHingeParam(_odeConstraint,dParamStopERP,stopERP);
		dJointSetHingeParam(_odeConstraint,dParamStopCFM,stopCFM);

		// Set the configuration of the child as if the joint was at 0 position:
		dBodyID cb=childBody->getOdeRigidBody();
		C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
		C7Vector alpha(jtr2.getInverse()*cb_a);
		C7Vector cb_b(jtr*alpha);
		dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
		dBodySetQuaternion(cb,cb_b.Q.data);


		// Attach the joint to the 2 bodies
		dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
		dJointSetHingeAnchor(_odeConstraint,jtr.X(0),jtr.X(1),jtr.X(2));
		dJointSetHingeAxis(_odeConstraint,jtrm.axis[2](0),jtrm.axis[2](1),jtrm.axis[2](2));

		// Reset the configuration of the child as it is now:
		dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
		dBodySetQuaternion(cb,cb_a.Q.data);

		// New since 1/6/2011:
		_odeJointFeedbackStructure=new dJointFeedback;
		dJointSetFeedback(_odeConstraint,_odeJointFeedbackStructure);
	}
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{
		_odeConstraint=dJointCreateSlider(odeWorldID,0);
		dJointSetSliderParam(_odeConstraint,dParamFudgeFactor,fudge);
		dJointSetSliderParam(_odeConstraint,dParamBounce,bounce);
		dJointSetSliderParam(_odeConstraint,dParamCFM,normalCFM);
		dJointSetSliderParam(_odeConstraint,dParamStopERP,stopERP);
		dJointSetSliderParam(_odeConstraint,dParamStopCFM,stopCFM);

		// Set the configuration of the child as if the joint was at 0 position:
		dBodyID cb=childBody->getOdeRigidBody();
		C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
		C7Vector alpha(jtr2.getInverse()*cb_a);
		C7Vector cb_b(jtr*alpha);
		dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
		dBodySetQuaternion(cb,cb_b.Q.data);

		// Attach the joint to the 2 bodies
		dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
		dJointSetSliderAxis(_odeConstraint,jtrm.axis[2](0),jtrm.axis[2](1),jtrm.axis[2](2));

		// Reset the configuration of the child as it is now:
		dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
		dBodySetQuaternion(cb,cb_a.Q.data);

		// New since 1/6/2011:
		_odeJointFeedbackStructure=new dJointFeedback;
		dJointSetFeedback(_odeConstraint,_odeJointFeedbackStructure);
	}
	if (_simGetJointType(joint)==sim_joint_spherical_subtype)
	{
		_odeConstraint=dJointCreateBall(odeWorldID,0);
		dJointSetBallParam(_odeConstraint,dParamFudgeFactor,fudge);
		dJointSetBallParam(_odeConstraint,dParamBounce,bounce);
		dJointSetBallParam(_odeConstraint,dParamCFM,normalCFM);
		dJointSetBallParam(_odeConstraint,dParamStopERP,stopERP);
		dJointSetBallParam(_odeConstraint,dParamStopCFM,stopCFM);

		// Set the configuration of the child as if the joint was at 0 position:
		dBodyID cb=childBody->getOdeRigidBody();
		C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
		C7Vector alpha(jtr2.getInverse()*cb_a);
		C7Vector cb_b(jtr*alpha);
		dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
		dBodySetQuaternion(cb,cb_b.Q.data);

		// Attach the joint to the 2 bodies
		dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
		dJointSetBallAnchor(_odeConstraint,jtr.X(0),jtr.X(1),jtr.X(2));

		// Reset the configuration of the child as it is now:
		dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
		dBodySetQuaternion(cb,cb_a.Q.data);
	}
		handleMotorControl(joint,0,0);
}

CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyJoint* joint,CDummyDummy* loopClosureDummyA,CDummyDummy* loopClosureDummyB,btDiscreteDynamicsWorld* bulletWorld)
{
	_physicsEngineType=sim_physics_bullet;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=_simGetObjectID(loopClosureDummyA);
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=_simGetObjectID(loopClosureDummyB);

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_jointIsCyclic=!_simGetJointPositionInterval(joint,&_nonCyclicRevoluteJointPositionMinimum,&_nonCyclicRevoluteJointPositionRange);
	_dummyID=-1;
	_forceSensorID=-1;
	_constraintID=-1;
	_jointID=_simGetObjectID(joint);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;

	// Following 4 lines are important when a joint is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(joint,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);

	_simGetObjectLocalTransformation(loopClosureDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data,false);
	_simGetObjectLocalTransformation(loopClosureDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data,false);

	// Following is DIFFERENT from the regular situation (non-looped):
	_simGetObjectLocalTransformation(loopClosureDummyB,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data,false);

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr;
	_simGetObjectCumulativeTransformation(joint,jtr.X.data,jtr.Q.data,true);

	// Following is DIFFERENT from the regular situation (non-looped):
	C7Vector tmpTr1;
	_simGetObjectCumulativeTransformation(loopClosureDummyB,tmpTr1.X.data,tmpTr1.Q.data,false);
	C7Vector jtr2(tmpTr1*_linkedDummyAInitialLocalTransform.getInverse());

	C3X3Matrix m;
	m.setIdentity();
	m.buildYRotation(1.5707963267f);
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{ // in Bullet the moving direction is the x-axis (not like V-REP the z-axis)
		jtr.Q=jtr.Q*m.getQuaternion();
		jtr2.Q=jtr2.Q*m.getQuaternion();
	}
	m.setIdentity();
	m.buildYRotation(piValue);
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{ // in Bullet the moving direction is the negative z-axis (not like V-REP the z-axis)
		C3X3Matrix jointOffsetThing;
		jointOffsetThing.setIdentity();
		if (_simGetJointPositionInterval(joint,NULL,NULL))
		{ // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
			_nonCyclicRevoluteJointPositionOffset=-_nonCyclicRevoluteJointPositionMinimum-_nonCyclicRevoluteJointPositionRange*0.5f;
			jointOffsetThing.buildZRotation(_nonCyclicRevoluteJointPositionOffset);
			_jointPosAlt=_simGetJointPosition(joint)+_nonCyclicRevoluteJointPositionOffset;
		}
		jtr.Q=jtr.Q*m.getQuaternion(); 
		jtr2.Q=jtr2.Q*jointOffsetThing.getQuaternion()*m.getQuaternion(); 
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	if ((parentBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		parentBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		parentBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

	if ((childBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		childBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		childBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING
	float stopERP,stopCFM,normalCFM;
	_simGetJointBulletParameters(joint,&stopERP,&stopCFM,&normalCFM);
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{
		btHingeConstraint* hinge;
		btTransform jtrA;
		jtrA.setOrigin(btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)));
		jtrA.setRotation(btQuaternion(jtrRelToBodyA.Q(1),jtrRelToBodyA.Q(2),jtrRelToBodyA.Q(3),jtrRelToBodyA.Q(0)));
		btTransform jtrB;
		jtrB.setOrigin(btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
		jtrB.setRotation(btQuaternion(jtrRelToBodyB.Q(1),jtrRelToBodyB.Q(2),jtrRelToBodyB.Q(3),jtrRelToBodyB.Q(0)));
		hinge=new btHingeConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),jtrA,jtrB,false);
		_constraint=hinge;

		// you have to modify the btHingeConstraint code and remove the -pi;+pi limitation in the setLimit routine!!!

		hinge->setParam(BT_CONSTRAINT_STOP_ERP,stopERP);
		hinge->setParam(BT_CONSTRAINT_STOP_CFM,stopCFM);
		hinge->setParam(BT_CONSTRAINT_CFM,normalCFM);
	}
	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{
		btSliderConstraint* slider;

		btTransform jtrA;
		jtrA.setOrigin(btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)));
		jtrA.setRotation(btQuaternion(jtrRelToBodyA.Q(1),jtrRelToBodyA.Q(2),jtrRelToBodyA.Q(3),jtrRelToBodyA.Q(0)));

		btTransform jtrB;
		jtrB.setOrigin(btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
		jtrB.setRotation(btQuaternion(jtrRelToBodyB.Q(1),jtrRelToBodyB.Q(2),jtrRelToBodyB.Q(3),jtrRelToBodyB.Q(0)));

		slider=new btSliderConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),jtrA,jtrB,false);
		_constraint=slider;

		slider->setParam(BT_CONSTRAINT_STOP_ERP,stopERP);
		slider->setParam(BT_CONSTRAINT_STOP_CFM,stopCFM);
		slider->setParam(BT_CONSTRAINT_CFM,normalCFM);
	}
	if (_simGetJointType(joint)==sim_joint_spherical_subtype)
	{
		btPoint2PointConstraint* ballSocket;
		ballSocket=new btPoint2PointConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)),btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
		_constraint=ballSocket;

		ballSocket->setParam(BT_CONSTRAINT_STOP_ERP,stopERP);
		ballSocket->setParam(BT_CONSTRAINT_STOP_CFM,stopCFM);
		ballSocket->setParam(BT_CONSTRAINT_CFM,normalCFM);
	}

	bulletWorld->addConstraint(_constraint);
	handleMotorControl(joint,0,0);
}




CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyDummy* dummyOnParent,CDummyDummy* dummyOnChild,dWorldID odeWorldID)
{
	_physicsEngineType=sim_physics_ode;
	_odeJointFeedbackStructure=NULL; // Only used with ODE force sensors or joints (1/6/2011)
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=-1; // not used here
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=-1; // not used here

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_jointID=-1;
	_forceSensorID=-1;
	_constraintID=-1;
	_dummyID=_simGetObjectID(dummyOnParent);
	_linkedDummyID=_simGetObjectID(dummyOnChild);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;
	_jointIsCyclic=false;

	_simGetObjectLocalTransformation(dummyOnParent,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	_simGetObjectLocalTransformation(dummyOnChild,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data,true);

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	// Following 4 lines are important when a dummy is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	C7Vector dtr,dtr2;
	_simGetObjectCumulativeTransformation(dummyOnParent,dtr.X.data,dtr.Q.data,true);
	_simGetObjectCumulativeTransformation(dummyOnChild,dtr2.X.data,dtr2.Q.data,true);

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector dtrRelToBodyA;
	C7Vector dtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	_bodyAID=parentBody->getRigidBodyID();

	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();

	dtr.X*=linScaling; // ********** SCALING
	dtr2.X*=linScaling; // ********** SCALING

	_odeConstraint=dJointCreateFixed(odeWorldID,0);

	// Set the configuration of the child as if the dummies were overlapping:
	dBodyID cb=childBody->getOdeRigidBody();
	C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
	C7Vector x(cb_a.getInverse()*dtr2);
	C7Vector cb_b(dtr*x.getInverse());
	dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
	dBodySetQuaternion(cb,cb_b.Q.data);

	// Attach the fixed joint to the 2 bodies:
	dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
	dJointSetFixed(_odeConstraint);

	// Reset the configuration of the child as it is now:
	dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
	dBodySetQuaternion(cb,cb_a.Q.data);
}


CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyDummy* dummyOnParent,CDummyDummy* dummyOnChild,btDiscreteDynamicsWorld* bulletWorld)
{
	_physicsEngineType=sim_physics_bullet;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=-1; // not used here
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=-1; // not used here

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_jointID=-1;
	_forceSensorID=-1;
	_constraintID=-1;
	_dummyID=_simGetObjectID(dummyOnParent);
	_linkedDummyID=_simGetObjectID(dummyOnChild);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;
	_jointIsCyclic=false;

	_simGetObjectLocalTransformation(dummyOnParent,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	_simGetObjectLocalTransformation(dummyOnChild,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data,true);

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	// Following 4 lines are important when a dummy is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	C7Vector dtr,dtr2;
	_simGetObjectCumulativeTransformation(dummyOnParent,dtr.X.data,dtr.Q.data,true);
	_simGetObjectCumulativeTransformation(dummyOnChild,dtr2.X.data,dtr2.Q.data,true);

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector dtrRelToBodyA;
	C7Vector dtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	if ((parentBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		parentBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		parentBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	batr=parentBody->getInertiaFrameTransformation();
	dtrRelToBodyA=batr.getInverse()*dtr;
	_bodyAID=parentBody->getRigidBodyID();

	if ((childBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		childBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		childBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	bbtr=childBody->getInertiaFrameTransformation();
	dtrRelToBodyB=bbtr.getInverse()*dtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	dtrRelToBodyA.X*=linScaling; // ********** SCALING
	dtrRelToBodyB.X*=linScaling; // ********** SCALING

	btGeneric6DofConstraint* generalConstraint;
	btTransform dtrA;
	dtrA.setOrigin(btVector3(dtrRelToBodyA.X(0),dtrRelToBodyA.X(1),dtrRelToBodyA.X(2)));
	dtrA.setRotation(btQuaternion(dtrRelToBodyA.Q(1),dtrRelToBodyA.Q(2),dtrRelToBodyA.Q(3),dtrRelToBodyA.Q(0)));
	btTransform dtrB;
	dtrB.setOrigin(btVector3(dtrRelToBodyB.X(0),dtrRelToBodyB.X(1),dtrRelToBodyB.X(2)));
	dtrB.setRotation(btQuaternion(dtrRelToBodyB.Q(1),dtrRelToBodyB.Q(2),dtrRelToBodyB.Q(3),dtrRelToBodyB.Q(0)));
	generalConstraint=new btGeneric6DofConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),dtrA,dtrB,true);

	// Lock all axes (translations are locked by default):
	generalConstraint->getRotationalLimitMotor(0)->m_loLimit=0.0f;
	generalConstraint->getRotationalLimitMotor(0)->m_hiLimit=0.0f;
	generalConstraint->getRotationalLimitMotor(1)->m_loLimit=0.0f;
	generalConstraint->getRotationalLimitMotor(1)->m_hiLimit=0.0f;
	generalConstraint->getRotationalLimitMotor(2)->m_loLimit=0.0f;
	generalConstraint->getRotationalLimitMotor(2)->m_hiLimit=0.0f;

	_constraint=generalConstraint;
	bulletWorld->addConstraint(_constraint);
}




CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyForceSensor* forceSensor,dWorldID odeWorldID)
{
	_physicsEngineType=sim_physics_ode;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=-1; // not used (non-looped case)
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=-1; // not used (non-looped case)

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_dummyID=-1;
	_constraintID=-1;
	_jointID=-1;
	_forceSensorID=_simGetObjectID(forceSensor);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;
	_jointIsCyclic=false;

	// Following 4 lines are important when a force sensor is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(forceSensor,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	C7Vector tmpTr1,tmpTr2;
	_simGetObjectCumulativeTransformation(childShape,tmpTr1.X.data,tmpTr1.Q.data,false);
	_simGetObjectCumulativeTransformation(forceSensor,tmpTr2.X.data,tmpTr2.Q.data,false);
	_secondInitialLocalTransform=tmpTr1.getInverse()*tmpTr2;

	// since 2010/02/13:
	if (_simIsForceSensorBroken(forceSensor)) 
	{
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		_secondInitialLocalTransform*=tmpTr1;
	}

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr,jtr2;
	_simGetObjectCumulativeTransformation(forceSensor,jtr.X.data,jtr.Q.data,true);
	_simGetObjectCumulativeTransformation(forceSensor,jtr2.X.data,jtr2.Q.data,false);

	// since 2010/02/13
	if (_simIsForceSensorBroken(forceSensor)) 
	{
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		jtr2*=tmpTr1;
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING

	jtr.X*=linScaling; // ********** SCALING
	jtr2.X*=linScaling; // ********** SCALING
	C3X3Matrix jtrm(jtr.Q);

	_odeConstraint=dJointCreateFixed(odeWorldID,0);
	dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
	dJointSetFixed(_odeConstraint);

	_odeJointFeedbackStructure=new dJointFeedback;
	dJointSetFeedback(_odeConstraint,_odeJointFeedbackStructure);

	_setForceSensorBrokenUnbrokenConstraints(NULL,_odeConstraint,forceSensor);
}


CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyForceSensor* forceSensor,btDiscreteDynamicsWorld* bulletWorld)
{
	_physicsEngineType=sim_physics_bullet;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=-1; // not used (non-looped case)
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=-1; // not used (non-looped case)

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_dummyID=-1;
	_constraintID=-1;
	_jointID=-1;
	_forceSensorID=_simGetObjectID(forceSensor);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;
	_jointIsCyclic=false;

	// Following 4 lines are important when a force sensor is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(forceSensor,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	C7Vector tmpTr1,tmpTr2;
	_simGetObjectCumulativeTransformation(childShape,tmpTr1.X.data,tmpTr1.Q.data,false);
	_simGetObjectCumulativeTransformation(forceSensor,tmpTr2.X.data,tmpTr2.Q.data,false);
	_secondInitialLocalTransform=tmpTr1.getInverse()*tmpTr2;



	 // since 2010/02/13:
	if (_simIsForceSensorBroken(forceSensor))
	{
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		_secondInitialLocalTransform*=tmpTr1;
	}

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr,jtr2;
	_simGetObjectCumulativeTransformation(forceSensor,jtr.X.data,jtr.Q.data,true);
	_simGetObjectCumulativeTransformation(forceSensor,jtr2.X.data,jtr2.Q.data,false);

	if (_simIsForceSensorBroken(forceSensor)) // since 2010/02/13
	{
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		jtr2*=tmpTr1;
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	if ((parentBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		parentBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		parentBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

	if ((childBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		childBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		childBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING

	btGeneric6DofConstraint* constr;
	btTransform jtrA;
	jtrA.setOrigin(btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)));
	jtrA.setRotation(btQuaternion(jtrRelToBodyA.Q(1),jtrRelToBodyA.Q(2),jtrRelToBodyA.Q(3),jtrRelToBodyA.Q(0)));
	btTransform jtrB;
	jtrB.setOrigin(btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
	jtrB.setRotation(btQuaternion(jtrRelToBodyB.Q(1),jtrRelToBodyB.Q(2),jtrRelToBodyB.Q(3),jtrRelToBodyB.Q(0)));
	constr=new btGeneric6DofConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),jtrA,jtrB,false);

	constr->setUseFrameOffset(false);

	_setForceSensorBrokenUnbrokenConstraints(constr,NULL,forceSensor);

	_constraint=constr;

	bulletWorld->addConstraint(_constraint);
}



CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyForceSensor* forceSensor,CDummyDummy* loopClosureDummyA,CDummyDummy* loopClosureDummyB,dWorldID odeWorldID)
{
	_physicsEngineType=sim_physics_ode;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=_simGetObjectID(loopClosureDummyA);
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=_simGetObjectID(loopClosureDummyB);

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_dummyID=-1;
	_constraintID=-1;
	_jointID=-1;
	_forceSensorID=_simGetObjectID(forceSensor);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;
	_jointIsCyclic=false;

	// Following 4 lines are important when a force sensor is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(forceSensor,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	_simGetObjectLocalTransformation(loopClosureDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data,false);
	_simGetObjectLocalTransformation(loopClosureDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data,false);


	// Following is DIFFERENT from the regular situation (non-looped):
	_simGetObjectLocalTransformation(loopClosureDummyB,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data,false);

	// Following is not needed for looped cases (_secondInitialLocalTransform is not used in that case), but anyway:
	if (_simIsForceSensorBroken(forceSensor)) // since 2010/02/13
	{
		C7Vector tmpTr1;
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		_secondInitialLocalTransform*=tmpTr1;
	}

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr;
	_simGetObjectCumulativeTransformation(forceSensor,jtr.X.data,jtr.Q.data,true);
	// Following is DIFFERENT from the regular situation (non-looped):
	C7Vector tmpTr1;
	_simGetObjectCumulativeTransformation(loopClosureDummyB,tmpTr1.X.data,tmpTr1.Q.data,false);
	C7Vector jtr2(tmpTr1*_linkedDummyAInitialLocalTransform.getInverse());

	 // since 2010/02/13
	if (_simIsForceSensorBroken(forceSensor))
	{
		C7Vector tmpTr1;
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		jtr2*=tmpTr1;
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING

	jtr.X*=linScaling; // ********** SCALING
	jtr2.X*=linScaling; // ********** SCALING

	_odeConstraint=dJointCreateFixed(odeWorldID,0);

	// Set the configuration of the child as if the joint was at 0 position:
	dBodyID cb=childBody->getOdeRigidBody();
	C7Vector cb_a(C4Vector(((float*)dBodyGetQuaternion(cb))),C3Vector(((float*)dBodyGetPosition(cb))));
	C7Vector alpha(jtr2.getInverse()*cb_a);
	C7Vector cb_b(jtr*alpha);
	dBodySetPosition(cb,cb_b.X(0),cb_b.X(1),cb_b.X(2));
	dBodySetQuaternion(cb,cb_b.Q.data);

	// Attach the joint to the 2 bodies
	dJointAttach(_odeConstraint,parentBody->getOdeRigidBody(),childBody->getOdeRigidBody());
	dJointSetFixed(_odeConstraint);

	// Reset the configuration of the child as it is now:
	dBodySetPosition(cb,cb_a.X(0),cb_a.X(1),cb_a.X(2));
	dBodySetQuaternion(cb,cb_a.Q.data);

	_odeJointFeedbackStructure=new dJointFeedback;
	dJointSetFeedback(_odeConstraint,_odeJointFeedbackStructure);

	_setForceSensorBrokenUnbrokenConstraints(NULL,_odeConstraint,forceSensor);
}


CConstraintDyn::CConstraintDyn(CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody,CDummyForceSensor* forceSensor,CDummyDummy* loopClosureDummyA,CDummyDummy* loopClosureDummyB,btDiscreteDynamicsWorld* bulletWorld)
{
	_physicsEngineType=sim_physics_bullet;
	_parentBody=parentBody;
	_childBody=childBody;
	_jointOrForceSensorLoopClosureLinkedDummyAChildID=_simGetObjectID(loopClosureDummyA);
	_jointOrForceSensorLoopClosureLinkedDummyBChildID=_simGetObjectID(loopClosureDummyB);

	_cumulativeErrorForIntegralParameter=0;
	_lastErrorForDerivativeParameter=0;
	_nonCyclicRevoluteJointPositionOffset=0.0f;
	_dummyID=-1;
	_constraintID=-1;
	_jointID=-1;
	_forceSensorID=_simGetObjectID(forceSensor);
	_lastEffortOnJoint=0.0f;
	_dynPassCount=0;
	_lastJointPosSet=false;
	_jointIsCyclic=false;

	// Following 4 lines are important when a force sensor is added during simulation for instance. At that time the shape's positions are not yet updated (this is called before stepSimulation and shape update)
	CDummy3DObject* parentShape=(CDummy3DObject*)_simGetObject(parentBody->getShapeID());
	CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(childBody->getShapeID());
	parentBody->reportConfigurationToShape((CDummyShape*)parentShape);
	childBody->reportConfigurationToShape((CDummyShape*)childShape);

	_simGetObjectLocalTransformation(forceSensor,_initialLocalTransform.X.data,_initialLocalTransform.Q.data,true);
	_simGetObjectLocalTransformation(loopClosureDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data,false);
	_simGetObjectLocalTransformation(loopClosureDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data,false);

	// Following is DIFFERENT from the regular situation (non-looped):
	_simGetObjectLocalTransformation(loopClosureDummyB,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data,false);

	// Following is not needed for looped cases (_secondInitialLocalTransform is not used in that case), but anyway:
	if (_simIsForceSensorBroken(forceSensor)) // since 2010/02/13
	{
		C7Vector tmpTr1;
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		_secondInitialLocalTransform*=tmpTr1;
	}

	_parentShapeID=parentBody->getShapeID();
	_childShapeID=childBody->getShapeID();

	C7Vector jtr;
	_simGetObjectCumulativeTransformation(forceSensor,jtr.X.data,jtr.Q.data,true);
	// Following is DIFFERENT from the regular situation (non-looped):
	C7Vector tmpTr1;
	_simGetObjectCumulativeTransformation(loopClosureDummyB,tmpTr1.X.data,tmpTr1.Q.data,false);
	C7Vector jtr2(tmpTr1*_linkedDummyAInitialLocalTransform.getInverse());

	 // since 2010/02/13
	if (_simIsForceSensorBroken(forceSensor))
	{
		C7Vector tmpTr1;
		_simGetDynamicForceSensorLocalTransformationPart2(forceSensor,tmpTr1.X.data,tmpTr1.Q.data);
		jtr2*=tmpTr1;
	}

	C7Vector batr;
	C7Vector bbtr;
	batr.setIdentity();
	bbtr.setIdentity();
	C7Vector jtrRelToBodyA;
	C7Vector jtrRelToBodyB;
	_bodyAID=-1;
	_bodyBID=-1;

	if ((parentBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		parentBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		parentBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	batr=parentBody->getInertiaFrameTransformation();
	jtrRelToBodyA=batr.getInverse()*jtr;
	_bodyAID=parentBody->getRigidBodyID();

	if ((childBody->getBtRigidBody()->getCollisionFlags()&(btCollisionObject::CF_KINEMATIC_OBJECT|btCollisionObject::CF_STATIC_OBJECT))==0)
	{ // this is a dynamic object
		childBody->getBtRigidBody()->setActivationState(DISABLE_DEACTIVATION);
		childBody->setDefaultActivationState(DISABLE_DEACTIVATION);
	}
	bbtr=childBody->getInertiaFrameTransformation();
	jtrRelToBodyB=bbtr.getInverse()*jtr2;
	_bodyBID=childBody->getRigidBodyID();

	float linScaling=CDynInterface::getPositionScalingFactorDyn();
	jtrRelToBodyA.X*=linScaling; // ********** SCALING
	jtrRelToBodyB.X*=linScaling; // ********** SCALING

	btGeneric6DofConstraint* constr;
	btTransform jtrA;
	jtrA.setOrigin(btVector3(jtrRelToBodyA.X(0),jtrRelToBodyA.X(1),jtrRelToBodyA.X(2)));
	jtrA.setRotation(btQuaternion(jtrRelToBodyA.Q(1),jtrRelToBodyA.Q(2),jtrRelToBodyA.Q(3),jtrRelToBodyA.Q(0)));
	btTransform jtrB;
	jtrB.setOrigin(btVector3(jtrRelToBodyB.X(0),jtrRelToBodyB.X(1),jtrRelToBodyB.X(2)));
	jtrB.setRotation(btQuaternion(jtrRelToBodyB.Q(1),jtrRelToBodyB.Q(2),jtrRelToBodyB.Q(3),jtrRelToBodyB.Q(0)));
	constr=new btGeneric6DofConstraint(*parentBody->getBtRigidBody(),*childBody->getBtRigidBody(),jtrA,jtrB,false);

	constr->setUseFrameOffset(false);

	_setForceSensorBrokenUnbrokenConstraints(constr,NULL,forceSensor);

	_constraint=constr;
	bulletWorld->addConstraint(_constraint);
}



void CConstraintDyn::handleMotorControl(CDummyJoint* joint,int passCnt,int totalPasses)
{ // Here we set joint limits, activate/deactivate motors, and do the control of the motors:
	if (_simGetJointType(joint)==sim_joint_revolute_subtype)
	{
		float torqueScaling=CDynInterface::getTorqueScalingFactorDyn();
		float dynStepSize=CDynInterface::getDynamicsInternalTimeStep();
		btHingeConstraint* hinge;
		if (_physicsEngineType==sim_physics_ode)
		{
			if (_simGetJointPositionInterval(joint,NULL,NULL)==0)
			{ // no limits
				dJointSetHingeParam(_odeConstraint,dParamLoStop,-dInfinity);
				dJointSetHingeParam(_odeConstraint,dParamHiStop,+dInfinity);
			}
			else
			{
				// Limits are symmetric since 18/11/2012, since we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems  (revolute joints only)
				if (_nonCyclicRevoluteJointPositionRange<=359.0f*piValue*2.0f/360.0f)
				{ // when the range is <359, we keep the limits on all the time
					dJointSetHingeParam(_odeConstraint,dParamLoStop,-_nonCyclicRevoluteJointPositionRange*0.5f);
					dJointSetHingeParam(_odeConstraint,dParamHiStop,+_nonCyclicRevoluteJointPositionRange*0.5f);
				}
				else
				{ // since 23/3/2014: some rev. joints need to be limited to a range>360deg (e.g. for motion planning), so we keep it pseudo-cyclic on the dynamic side
					// ODE doesn't support a range > 360. So we manually turn limits on/off as needed:
					// That doesn't work in ODE. We leave it unlimited:
					float a=getHingeAngle();
					if (false)//a<-_nonCyclicRevoluteJointPositionRange*0.5f+3.14159265f)
					{
						float m=fmod(-_nonCyclicRevoluteJointPositionRange*0.5f,3.14159265f);
						dJointSetHingeParam(_odeConstraint,dParamLoStop,m); // low limit on
					}
					else
						dJointSetHingeParam(_odeConstraint,dParamLoStop,-dInfinity); // low limit off
					if (false)//a>_nonCyclicRevoluteJointPositionRange*0.5f-3.14159265f)
						dJointSetHingeParam(_odeConstraint,dParamHiStop,+_nonCyclicRevoluteJointPositionRange*0.5f); // high limit on
					else
						dJointSetHingeParam(_odeConstraint,dParamHiStop,+dInfinity); // high limit off
				}
			}
		}
		if (_physicsEngineType==sim_physics_bullet)
		{
			hinge=(btHingeConstraint*)_constraint;
			if (_simGetJointPositionInterval(joint,NULL,NULL)==0)
				hinge->setLimit(+1.0f,-1.0f); // no limits
			else
			{ // Limits are symmetric since 18/11/2012, since we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems  (revolute joints only)
				if (_nonCyclicRevoluteJointPositionRange<=359.0f*piValue*2.0f/360.0f)
				{ // when the range is <359, we keep the limits on all the time
					hinge->setLimit(-_nonCyclicRevoluteJointPositionRange*0.5f,+_nonCyclicRevoluteJointPositionRange*0.5f); // active limits. Limits are symmetric since 18/11/2012, since we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
				}
				else
				{ // Bullet doesn't support a range > 360. So we manually turn limits on/off as needed:
					// That doesn't work in Bullet. We leave it unlimited for now:
					hinge->setLimit(+1.0f,-1.0f); // no limits
				}
			}
		}


		if (totalPasses!=0)
		{ // execute this part not twice if the joint just got added
			// Now the control part:
			if (_simIsDynamicMotorEnabled(joint)&&_simIsDynamicMotorPositionCtrlEnabled(joint))
			{ // control loop enabled
				float e;
				if (_simGetJointPositionInterval(joint,NULL,NULL)==0)
					e=getAngleMinusAlpha(_simGetDynamicMotorTargetPosition(joint)+_nonCyclicRevoluteJointPositionOffset,getHingeAngle()); // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
				else
					e=_simGetDynamicMotorTargetPosition(joint)+_nonCyclicRevoluteJointPositionOffset-getHingeAngle(); // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)

				int auxV=0;
				if (_dynPassCount==0)
					auxV|=1;
				int inputValuesInt[5];
				inputValuesInt[0]=passCnt;
				inputValuesInt[1]=totalPasses;
				inputValuesInt[2]=0; // reserved for future ext.
				inputValuesInt[3]=0; // reserved for future ext.
				inputValuesInt[4]=0; // reserved for future ext.
				float inputValuesFloat[7];
				inputValuesFloat[0]=getHingeAngle()-_nonCyclicRevoluteJointPositionOffset;
				inputValuesFloat[1]=_lastEffortOnJoint;
				inputValuesFloat[2]=dynStepSize;
				inputValuesFloat[3]=e;
				inputValuesFloat[4]=0.0f; // reserved for future ext.
				inputValuesFloat[5]=0.0f; // reserved for future ext.
				inputValuesFloat[6]=0.0f; // reserved for future ext.
				float outputValues[5];
				_simHandleJointControl(joint,auxV,inputValuesInt,inputValuesFloat,outputValues);
				float velocityToApply=outputValues[0];
				float forceToApply=outputValues[1];

				if (_physicsEngineType==sim_physics_ode)
				{
					dJointSetHingeParam(_odeConstraint,dParamFMax,forceToApply*torqueScaling); // ********** SCALING
					dJointSetHingeParam(_odeConstraint,dParamVel,velocityToApply);
				}
				if (_physicsEngineType==sim_physics_bullet)
					hinge->enableAngularMotor(true,velocityToApply,forceToApply*torqueScaling*dynStepSize); // ********** SCALING
			}
			else
			{
				float vel=_simGetDynamicMotorTargetVelocity(joint);

				_cumulativeErrorForIntegralParameter=0;
				_lastErrorForDerivativeParameter=0;
				if (_physicsEngineType==sim_physics_ode)
				{
					if (_simIsDynamicMotorEnabled(joint))
					{ // Motor on
						dJointSetHingeParam(_odeConstraint,dParamFMax,_simGetDynamicMotorMaxForce(joint)*torqueScaling); // ********** SCALING
						dJointSetHingeParam(_odeConstraint,dParamVel,vel);
					}
					else
						dJointSetHingeParam(_odeConstraint,dParamFMax,0.0f); // Motor off
				}
				if (_physicsEngineType==sim_physics_bullet)
					hinge->enableAngularMotor(_simIsDynamicMotorEnabled(joint)!=0,vel,_simGetDynamicMotorMaxForce(joint)*torqueScaling*dynStepSize); // ********** SCALING
			}
		}
	}

	if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
	{
		float linScaling=CDynInterface::getPositionScalingFactorDyn();
		float linVelocityScaling=CDynInterface::getLinearVelocityScalingFactorDyn();
		float forceScaling=CDynInterface::getForceScalingFactorDyn();
		float dynStepSize=CDynInterface::getDynamicsInternalTimeStep();
		btSliderConstraint* slider;
		float jiMin,jiRange;
		_simGetJointPositionInterval(joint,&jiMin,&jiRange);
		if (_physicsEngineType==sim_physics_ode)
		{
			dJointSetSliderParam(_odeConstraint,dParamLoStop,jiMin*linScaling); // ********** SCALING
			dJointSetSliderParam(_odeConstraint,dParamHiStop,(jiMin+jiRange)*linScaling); // ********** SCALING
		}
		if (_physicsEngineType==sim_physics_bullet)
		{
			slider=(btSliderConstraint*)_constraint;
			slider->setLowerLinLimit(jiMin*linScaling); // ********** SCALING
			slider->setUpperLinLimit((jiMin+jiRange)*linScaling); // ********** SCALING
		}


		if (totalPasses!=0)
		{ // execute this part not twice if the joint just got added
			// Now the control part:
			if (_simIsDynamicMotorEnabled(joint)&&_simIsDynamicMotorPositionCtrlEnabled(joint))
			{ // control loop enabled
				float e=_simGetDynamicMotorTargetPosition(joint)-getSliderPositionScaled()/linScaling; // ********** SCALING

				int auxV=0;
				if (_dynPassCount==0)
					auxV|=1;
				int inputValuesInt[5];
				inputValuesInt[0]=passCnt;
				inputValuesInt[1]=totalPasses;
				inputValuesInt[2]=0; // reserved for future ext.
				inputValuesInt[3]=0; // reserved for future ext.
				inputValuesInt[4]=0; // reserved for future ext.
				float inputValuesFloat[7];
				inputValuesFloat[0]=getSliderPositionScaled()/linScaling; // Scaling was forgotten and added on 22/8/2013, thanks to Ruediger Dehmel.
				inputValuesFloat[1]=_lastEffortOnJoint;
				inputValuesFloat[2]=dynStepSize;
				inputValuesFloat[3]=e;
				inputValuesFloat[4]=0.0f; // reserved for future ext.
				inputValuesFloat[5]=0.0f; // reserved for future ext.
				inputValuesFloat[6]=0.0f; // reserved for future ext.
				float outputValues[5];
				_simHandleJointControl(joint,auxV,inputValuesInt,inputValuesFloat,outputValues);
				float velocityToApply=outputValues[0];
				float forceToApply=outputValues[1];

				if (_physicsEngineType==sim_physics_ode)
				{
					dJointSetSliderParam(_odeConstraint,dParamFMax,forceToApply*forceScaling); // ********** SCALING
					dJointSetSliderParam(_odeConstraint,dParamVel,velocityToApply*linVelocityScaling); // ********** SCALING
				}
				if (_physicsEngineType==sim_physics_bullet)
				{
					slider->setPoweredLinMotor(true);
					slider->setTargetLinMotorVelocity(velocityToApply*linVelocityScaling); // ********** SCALING
					slider->setMaxLinMotorForce(forceToApply*forceScaling*dynStepSize*dynStepSize); // ********** SCALING
				}
			}
			else
			{
				float vel=_simGetDynamicMotorTargetVelocity(joint);
				_cumulativeErrorForIntegralParameter=0;
				_lastErrorForDerivativeParameter=0;

				if (_physicsEngineType==sim_physics_ode)
				{
					if (_simIsDynamicMotorEnabled(joint))
					{ // Motor on
						dJointSetSliderParam(_odeConstraint,dParamFMax,_simGetDynamicMotorMaxForce(joint)*forceScaling);// ********** SCALING
						dJointSetSliderParam(_odeConstraint,dParamVel,vel*linVelocityScaling); // ********** SCALING
					}
					else
						dJointSetSliderParam(_odeConstraint,dParamFMax,0.0f); // Motor off
				}
				if (_physicsEngineType==sim_physics_bullet)
				{
					slider->setPoweredLinMotor(_simIsDynamicMotorEnabled(joint)!=0);
					slider->setTargetLinMotorVelocity(vel*linVelocityScaling); // ********** SCALING
					slider->setMaxLinMotorForce(_simGetDynamicMotorMaxForce(joint)*forceScaling*dynStepSize*dynStepSize); // ********** SCALING
				}
			}
		}
	}
}

float CConstraintDyn::getSliderPositionScaled()
{ // important! The slider pos is not initialized when added! (at least in debug mode, it is not! (release it is I think))
	float linScaling=CDynInterface::getPositionScalingFactorDyn();

	if (_physicsEngineType==sim_physics_ode)
		return(dJointGetSliderPosition(_odeConstraint)*linScaling);

	if (_physicsEngineType==sim_physics_bullet)
	{
		C7Vector p(_parentBody->getShapeFrameTransformation());
		C7Vector c(_childBody->getShapeFrameTransformation());
		p=p*_initialLocalTransform;
		c=c*_secondInitialLocalTransform;
		if (_jointOrForceSensorLoopClosureLinkedDummyAChildID!=-1)
			c=c*_linkedDummyAInitialLocalTransform.getInverse(); // Non-regular case (looped) (bug correction on 2010/10/08)
		return((p.getInverse()*c.X)(2)*linScaling);
	}


	return(0.0f);
}

float CConstraintDyn::getHingeAngle()
{
	float retVal=0.0f;
//	if ((_physicsEngineType==sim_physics_ode)||(_physicsEngineType==sim_physics_bullet))
	if (true)
	{ // Bullet and ODE do not take into account turn count. So we need to handle this manually here:
		float jointPos;
		if (_physicsEngineType==sim_physics_ode)
		{
			jointPos=dJointGetHingeAngle(_odeConstraint);
		}
		if (_physicsEngineType==sim_physics_bullet)
		{
			jointPos=((btHingeConstraint*)_constraint)->getHingeAngle();
		}
		if (_jointIsCyclic)
		{ // turn count not needed here
			retVal=jointPos;
		}
		else
		{
			if (_lastJointPosSet)
			{
				float dx=jointPos-_lastJointPos;
				if (dx>=0.0f)
					dx=fmod(dx+3.14159265f,6.28318531f)-3.14159265f;
				else
					dx=fmod(dx-3.14159265f,6.28318531f)+3.14159265f;
				_jointPosAlt+=dx;
			}
			retVal=_jointPosAlt;
		}
		_lastJointPos=jointPos;
		_lastJointPosSet=true;
	}
/*
#ifdef INCLUDE_VORTEX_CODE
	if (_physicsEngineType==sim_physics_vortex)
	{
		// note if the constraint was never stepped, this will return 0.
		// an alternative is to return _vortexConstraint->recalculateCoordinateCurrentPosition(VortexPrismCoordinate);
		// which is slower but works all the time
 //       return (float)_vortexConstraint->getCoordinateCurrentPosition(VortexHingeCoordinate);
		retVal=(float)_vortexConstraint->recalculateCoordinateCurrentPosition(VortexPrismCoordinate);

		if (_jointIsCyclic)
		{
			retVal=fmod(retVal,6.2831853f);
			if (retVal<-3.1415926)
				retVal+=6.2831853f;
			else if (retVal>+3.1415926)
				retVal-=6.2831853f;
		}

		_lastJointPos=retVal; // not really needed wih Vortex
		_lastJointPosSet=true; // not really needed wih Vortex
	}
#endif // INCLUDE_VORTEX_CODE
*/
	return(retVal);
}

int CConstraintDyn::getParentShapeID()
{
	return(_parentShapeID);
}
int CConstraintDyn::getChildShapeID()
{
	return(_childShapeID);
}

bool CConstraintDyn::getIsJoint()
{
	return(_jointID!=-1);
}

bool CConstraintDyn::announceBodyWillBeDestroyed(int bodyID)
{ // return value true means: this constraint should be removed
	return( (bodyID==_bodyAID)||(bodyID==_bodyBID) );
}

CConstraintDyn::~CConstraintDyn()
{
	if (_physicsEngineType==sim_physics_ode)
	{
		dJointDestroy(_odeConstraint);
		delete _odeJointFeedbackStructure;
	}
	if (_physicsEngineType==sim_physics_bullet)
	{
		delete _constraint;
	}
}

void CConstraintDyn::setConstraintID(int newID)
{
	_constraintID=newID;
}

int CConstraintDyn::getConstraintID()
{
	return(_constraintID);
}

btTypedConstraint* CConstraintDyn::getBtTypedConstraint()
{
	return(_constraint);
}

int CConstraintDyn::getJointID()
{
	return(_jointID);
}

int CConstraintDyn::getDummyID()
{
	return(_dummyID);
}

int CConstraintDyn::getForceSensorID()
{
	return(_forceSensorID);
}

void CConstraintDyn::reportConfigurationToJoint(CDummyJoint* joint,CDummyDummy* linkedDummyA,CDummyDummy* linkedDummyB,bool doNotApplyJointIntrinsicPosition)//,CRigidBodyDyn* parentBody,CRigidBodyDyn* childBody)
{
	if (_simGetDynamicsFullRefreshFlag(joint))
		return; // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
	if (_jointID!=-1)
	{
		float linScaling=CDynInterface::getPositionScalingFactorDyn();
		_simSetObjectLocalTransformation(joint,_initialLocalTransform.X.data,_initialLocalTransform.Q.data);

		if (linkedDummyA!=NULL)
		{ // special case (looped)
			_simSetObjectLocalTransformation(linkedDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data);
			_simSetObjectLocalTransformation(linkedDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data);
		}

		float forceScaling=CDynInterface::getForceScalingFactorDyn();
		float torqueScaling=CDynInterface::getTorqueScalingFactorDyn();
		float dynStepSize=CDynInterface::getDynamicsInternalTimeStep();
		if (!doNotApplyJointIntrinsicPosition)
		{
			if (_simGetJointType(joint)==sim_joint_revolute_subtype)
				_simSetDynamicMotorReflectedPositionFromDynamicEngine(joint,getHingeAngle()-_nonCyclicRevoluteJointPositionOffset); // since 18/11/2012 we are using an offset between V-REP joint position and Bullet/ODE joint position to avoid problems with limits (revolute joints only)
			if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
				_simSetDynamicMotorReflectedPositionFromDynamicEngine(joint,getSliderPositionScaled()/linScaling); // ********** SCALING
			if (_simGetJointType(joint)==sim_joint_spherical_subtype)
			{ // a bit more troublesome here!
				C7Vector parentCumul(_parentBody->getShapeFrameTransformation());	
				C7Vector childCumul(_childBody->getShapeFrameTransformation());
				C7Vector p(parentCumul*_initialLocalTransform);
				C7Vector c;
				if (linkedDummyA!=NULL)
					c=childCumul*_linkedDummyBInitialLocalTransform*_linkedDummyAInitialLocalTransform.getInverse(); // special case (looped)
				else
					c=childCumul*_secondInitialLocalTransform; // regular case (non-looped)
				C7Vector x(p.getInverse()*c);
				_simSetJointSphericalTransformation(joint,x.Q.data);
			}
		}
	}
}

void CConstraintDyn::reportSecondPartConfigurationToJoint(CDummyJoint* joint)
{ // this has a purely visual effect (only showing the joint's second part position)
	if (_simGetDynamicsFullRefreshFlag(joint))
		return; // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
	if (_jointID!=-1)
	{
		CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(_childShapeID);
		if (childShape!=NULL)
		{
			C7Vector cumul;
			C7Vector tmpTr;
			_simGetObjectCumulativeTransformation(childShape,tmpTr.X.data,tmpTr.Q.data,true);
			if (_jointOrForceSensorLoopClosureLinkedDummyAChildID!=-1)
				cumul=tmpTr*_linkedDummyBInitialLocalTransform*_linkedDummyAInitialLocalTransform.getInverse(); // special case (looped)
			else
				cumul=tmpTr*_secondInitialLocalTransform; // regular case (non-looped)

			C7Vector jCumul;
			_simGetObjectCumulativeTransformation(joint,jCumul.X.data,jCumul.Q.data,true);

			jCumul.inverse();
			jCumul=jCumul*cumul;
			_simSetDynamicJointLocalTransformationPart2(joint,jCumul.X.data,jCumul.Q.data);
			_simSetDynamicJointLocalTransformationPart2IsValid(joint,true);
		}
	}
}

void CConstraintDyn::reportConfigurationToDummies(CDummyDummy* dummyParent,CDummyDummy* dummyChild)
{
	if (_dummyID!=-1)
	{
		if (_simGetDynamicsFullRefreshFlag(dummyParent)==0) // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
			_simSetObjectLocalTransformation(dummyParent,_initialLocalTransform.X.data,_initialLocalTransform.Q.data);
		if (_simGetDynamicsFullRefreshFlag(dummyChild)==0) // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
			_simSetObjectLocalTransformation(dummyChild,_secondInitialLocalTransform.X.data,_secondInitialLocalTransform.Q.data);
	}
}

void CConstraintDyn::reportConfigurationAndForcesToForceSensor(CDummyForceSensor* forceSensor,CDummyDummy* linkedDummyA,CDummyDummy* linkedDummyB,int totalPassesCount)
{ // totalPassesCount is 0 when we need to accumulate the values, and diff. from zero when we need to average!
	// If totalPassesCount is -1, then we do not report the forces and torques!
	if (_simGetDynamicsFullRefreshFlag(forceSensor))
		return; // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
	if (_forceSensorID!=-1)
	{
		float linScaling=CDynInterface::getPositionScalingFactorDyn();
		_simSetObjectLocalTransformation(forceSensor,_initialLocalTransform.X.data,_initialLocalTransform.Q.data);

		if (linkedDummyA!=NULL)
		{ // special case (looped)
			_simSetObjectLocalTransformation(linkedDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data);
			_simSetObjectLocalTransformation(linkedDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data);
		}

		float forceScaling=CDynInterface::getForceScalingFactorDyn();
		float torqueScaling=CDynInterface::getTorqueScalingFactorDyn();
		float dynStepSize=CDynInterface::getDynamicsInternalTimeStep();
		// Now report forces and torques acting on the joint:
		if (totalPassesCount!=-1)
		{
			C3Vector forces;
			forces.clear();
			C3Vector torques;
			torques.clear();
			int n=0;

			if (_physicsEngineType==sim_physics_ode)
			{
				if (_simIsForceSensorBroken(forceSensor)==0)
				{
					C3Vector absF(_odeJointFeedbackStructure->f2[0],_odeJointFeedbackStructure->f2[1],_odeJointFeedbackStructure->f2[2]);
					absF/=forceScaling; // ********** SCALING
					C3Vector absT(_odeJointFeedbackStructure->t2[0],_odeJointFeedbackStructure->t2[1],_odeJointFeedbackStructure->t2[2]);
					absT/=torqueScaling; // ********** SCALING
					C7Vector childBodyAbsConf(_childBody->getInertiaFrameTransformation());

					C7Vector parentShapeAbsConf(_parentBody->getShapeFrameTransformation());
					C7Vector sensorAbsConf(parentShapeAbsConf*_initialLocalTransform);

					C3Vector absCorrectionV(sensorAbsConf.X-childBodyAbsConf.X);
					absT+=absF^absCorrectionV;
					
					C4Vector sensorAbsInverseQ(sensorAbsConf.Q.getInverse());
					forces=sensorAbsInverseQ*(absF*-1.0f);
					torques=sensorAbsInverseQ*(absT*-1.0f);
				}
			}
			if (_physicsEngineType==sim_physics_bullet)
			{
				if (((btGeneric6DofConstraint*)_constraint)->getTranslationalLimitMotor()->needApplyForce(0))
					forces(0)=_constraint->m_appliedImpulse_byMarc[n++]/(forceScaling*dynStepSize); // x
				if (((btGeneric6DofConstraint*)_constraint)->getTranslationalLimitMotor()->needApplyForce(1))
					forces(1)=_constraint->m_appliedImpulse_byMarc[n++]/(forceScaling*dynStepSize); // y
				if (((btGeneric6DofConstraint*)_constraint)->getTranslationalLimitMotor()->needApplyForce(2))
					forces(2)=_constraint->m_appliedImpulse_byMarc[n++]/(forceScaling*dynStepSize); // z

				if (((btGeneric6DofConstraint*)_constraint)->getRotationalLimitMotor(0)->needApplyTorques())
					torques(0)=_constraint->m_appliedImpulse_byMarc[n++]/(torqueScaling*dynStepSize); // alpha
				if (((btGeneric6DofConstraint*)_constraint)->getRotationalLimitMotor(1)->needApplyTorques())
					torques(1)=_constraint->m_appliedImpulse_byMarc[n++]/(torqueScaling*dynStepSize); // beta
				if (((btGeneric6DofConstraint*)_constraint)->getRotationalLimitMotor(2)->needApplyTorques())
					torques(2)=_constraint->m_appliedImpulse_byMarc[n++]/(torqueScaling*dynStepSize); // gamma
			}


			_simAddForceSensorCumulativeForcesAndTorques(forceSensor,forces.data,torques.data,totalPassesCount);
			if (totalPassesCount>0)
				_setForceSensorBrokenUnbrokenConstraints((btGeneric6DofConstraint*)_constraint,_odeConstraint,forceSensor);
		}
	}
}

void CConstraintDyn::reportSecondPartConfigurationToForceSensor(CDummyForceSensor* forceSensor)
{ // this has a purely visual effect (only showing the force sensor's second part position)
	if (_simGetDynamicsFullRefreshFlag(forceSensor))
		return; // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
	if (_forceSensorID!=-1)
	{
		CDummy3DObject* childShape=(CDummy3DObject*)_simGetObject(_childShapeID);
		if (childShape!=NULL)
		{
			C7Vector cumul;
			C7Vector tmpTr;
			_simGetObjectCumulativeTransformation(childShape,tmpTr.X.data,tmpTr.Q.data,true);
			if (_jointOrForceSensorLoopClosureLinkedDummyAChildID!=-1)
				cumul=tmpTr*_linkedDummyBInitialLocalTransform*_linkedDummyAInitialLocalTransform.getInverse(); // special case (looped)
			else
				cumul=tmpTr*_secondInitialLocalTransform; // regular case (non-looped)
			C7Vector jCumul;
			_simGetObjectCumulativeTransformation(forceSensor,jCumul.X.data,jCumul.Q.data,true);
			jCumul.inverse();
			jCumul=jCumul*cumul;
			_simSetDynamicForceSensorLocalTransformationPart2(forceSensor,jCumul.X.data,jCumul.Q.data);
			_simSetDynamicForceSensorLocalTransformationPart2IsValid(forceSensor,true);
		}
	}
}

void CConstraintDyn::reportForcesToJoint(CDummyJoint* joint,CDummyDummy* linkedDummyA,CDummyDummy* linkedDummyB,int totalPassesCount)
{ // totalPassesCount is 0 when we need to accumulate the values, and diff. from zero when we need to average!
	// If totalPassesCount is -1, then we do not report the forces and torques!
	if (_simGetDynamicsFullRefreshFlag(joint))
		return; // added on 2010/02/08 (otherwise problems when models are scaled during simulation)
	if (_jointID!=-1)
	{
		float linScaling=CDynInterface::getPositionScalingFactorDyn();

		// Is following correct for joints?? Dummies are actualized after joints! Decided to keep this on 1/6/2011
		if (linkedDummyA!=NULL)
		{ // special case (looped)
			_simSetObjectLocalTransformation(linkedDummyA,_linkedDummyAInitialLocalTransform.X.data,_linkedDummyAInitialLocalTransform.Q.data);
			_simSetObjectLocalTransformation(linkedDummyB,_linkedDummyBInitialLocalTransform.X.data,_linkedDummyBInitialLocalTransform.Q.data);
		}

		float forceScaling=CDynInterface::getForceScalingFactorDyn();
		float torqueScaling=CDynInterface::getTorqueScalingFactorDyn();
		float dynStepSize=CDynInterface::getDynamicsInternalTimeStep();
		// Now report forces and torques acting on the joint:
		if (totalPassesCount!=-1)
		{
			float forceOrTorque=0.0f;

			if (_physicsEngineType==sim_physics_ode)
			{
				if (_simGetJointType(joint)!=sim_joint_spherical_subtype)
				{ // Spherical joints are not supported here!
					C3Vector absF(_odeJointFeedbackStructure->f2[0],_odeJointFeedbackStructure->f2[1],_odeJointFeedbackStructure->f2[2]);
					absF/=forceScaling; // ********** SCALING
					C3Vector absT(_odeJointFeedbackStructure->t2[0],_odeJointFeedbackStructure->t2[1],_odeJointFeedbackStructure->t2[2]);
					absT/=torqueScaling; // ********** SCALING
					C7Vector childBodyAbsConf(_childBody->getInertiaFrameTransformation());

					C7Vector parentShapeAbsConf(_parentBody->getShapeFrameTransformation());
					C7Vector sensorAbsConf(parentShapeAbsConf*_initialLocalTransform);

					C3Vector absCorrectionV(sensorAbsConf.X-childBodyAbsConf.X);
					absT+=absF^absCorrectionV;
					
					C4Vector sensorAbsInverseQ(sensorAbsConf.Q.getInverse());
					C3Vector forces(sensorAbsInverseQ*(absF*-1.0f));
					C3Vector torques(sensorAbsInverseQ*(absT*-1.0f));
					if (_simGetJointType(joint)==sim_joint_revolute_subtype)
					{
						forceOrTorque=torques(2);
					}
					if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
					{
						forceOrTorque=forces(2);
					}

				}
			}

			if (_physicsEngineType==sim_physics_bullet)
			{
				if (_simGetJointType(joint)!=sim_joint_spherical_subtype)
				{ // Spherical joints are not supported here
					if (_simGetJointType(joint)==sim_joint_revolute_subtype)
					{ // Found about the index and sign by trying.... 1/6/2011
						forceOrTorque=-_constraint->m_appliedImpulse_byMarc[5]/(torqueScaling*dynStepSize);
					}
					if (_simGetJointType(joint)==sim_joint_prismatic_subtype)
					{ // Found about the index and sign by trying.... 1/6/2011
						forceOrTorque=-_constraint->m_appliedImpulse_byMarc[4]/(forceScaling*dynStepSize);
					}

				}
			}



			_lastEffortOnJoint=forceOrTorque;
			_simAddJointCumulativeForcesOrTorques(joint,forceOrTorque,totalPassesCount);
		}
	}
}


void CConstraintDyn::_setForceSensorBrokenUnbrokenConstraints(btGeneric6DofConstraint* constr,dJointID odeConstr,CDummyForceSensor* forceSensor)
{
	if (_physicsEngineType==sim_physics_ode)
	{
		if (_simIsForceSensorBroken(forceSensor))
			dJointAttach(odeConstr,NULL,NULL);		
	}
	if (_physicsEngineType==sim_physics_bullet)
	{
		btTranslationalLimitMotor* m=constr->getTranslationalLimitMotor();
		btRotationalLimitMotor* r[3];
		r[0]=constr->getRotationalLimitMotor(0);
		r[1]=constr->getRotationalLimitMotor(1);
		r[2]=constr->getRotationalLimitMotor(2);

		for (int i=0;i<3;i++) // First translational constraints:
		{
			if (_simIsForceSensorBroken(forceSensor)==0)
			{
				m->m_lowerLimit[i]=0.0f;
				m->m_upperLimit[i]=0.0f;
				m->m_enableMotor[i]=true;
				m->m_targetVelocity[i]=0.0f;
				m->m_maxMotorForce[i]=SIM_MAX_FLOAT;
			}
			else
			{
				m->m_lowerLimit[i]=1.0f;
				m->m_upperLimit[i]=-1.0f;
				m->m_enableMotor[i]=false;
			}
		}

		for (int i=0;i<3;i++) // Now rotational constraints:
		{
			if (_simIsForceSensorBroken(forceSensor)==0)
			{
				r[i]->m_loLimit=0.0f;
				r[i]->m_hiLimit=0.0f;
				r[i]->m_enableMotor=true;
				r[i]->m_targetVelocity=0.0f;
				r[i]->m_maxMotorForce=SIM_MAX_FLOAT;
			}
			else
			{
				r[i]->m_loLimit=1.0f;
				r[i]->m_hiLimit=-1.0f;
				r[i]->m_enableMotor=false;
			}
		}
	}
}

int CConstraintDyn::getJointOrForceSensorLoopClosureLinkedDummyAChildID()
{
	return(_jointOrForceSensorLoopClosureLinkedDummyAChildID);
}

int CConstraintDyn::getJointOrForceSensorLoopClosureLinkedDummyBChildID()
{
	return(_jointOrForceSensorLoopClosureLinkedDummyBChildID);
}

void CConstraintDyn::incrementDynPassCounter()
{
	_dynPassCount++;
}

float CConstraintDyn::getAngleMinusAlpha(float angle,float alpha)
{	// Returns angle-alpha. Angle and alpha are angles (cyclic)!!
	// First we shift angle to zero (alpha follows):
	alpha=alpha-angle;
	// We limit alpha to values between 0 and 2Pi
	alpha=fmod(alpha,6.28318531f);
	if (alpha<0.0f)
		alpha=alpha+6.28318531f;
	if (alpha>piValue)
		return(6.28318531f-alpha); // angle is bigger
	else
		return(-alpha); // angle is smaller
}


