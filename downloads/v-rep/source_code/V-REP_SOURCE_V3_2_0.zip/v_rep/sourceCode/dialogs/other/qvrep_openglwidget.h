// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2014 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.0 on Feb. 3rd 2015

#ifndef QVREP_OPENGLWIDGET_H
#define QVREP_OPENGLWIDGET_H

struct SMouseOrKeyboardEvent
{
	int eventType;
	int button;
	int x;
	int y;
	bool ctrlDown;
	bool shiftDown;
	int wheelDelta;
	int key;
	int specialKey;
	QString unicodeText;
};

class COpenglWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit COpenglWidget(QWidget *parent = 0);
    ~COpenglWidget();

	void setOpenGlDisplayEnabled(bool e);
	bool getOpenGlDisplayEnabled();

protected:
	void _handleMouseAndKeyboardEvents(void* event,int t);

	void mousePressEvent(QMouseEvent* mEvent);
	void _mousePressEvent(SMouseOrKeyboardEvent e);
	void mouseReleaseEvent(QMouseEvent* mEvent);
	void _mouseReleaseEvent(SMouseOrKeyboardEvent e);
	void mouseDoubleClickEvent(QMouseEvent* mEvent);
	void _mouseDoubleClickEvent(SMouseOrKeyboardEvent e);
	void mouseMoveEvent(QMouseEvent* mEvent);
	void _mouseMoveEvent(SMouseOrKeyboardEvent e);

	void wheelEvent(QWheelEvent* wEvent);
	void _wheelEvent(SMouseOrKeyboardEvent e);

	void keyPressEvent(QKeyEvent* kEvent);
	void _keyPressEvent(SMouseOrKeyboardEvent e);
	void keyReleaseEvent(QKeyEvent* kEvent);
	void _keyReleaseEvent(SMouseOrKeyboardEvent e);



    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);

	void paintEvent(QPaintEvent* event);
	void resizeEvent(QResizeEvent* event);

	bool _openGlDisplayEnabled;

signals:

private slots:
	void _timer100ms_fire();

};
#endif // QVREP_OPENGLWIDGET_H
