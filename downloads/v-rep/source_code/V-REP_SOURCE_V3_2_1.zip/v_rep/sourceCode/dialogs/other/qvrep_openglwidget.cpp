// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2015 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.1 on May 3rd 2015

#include "qvrep_openglwidget.h"
#include "IloIlo.h"
#include <QMouseEvent>
#include "VDateTime.h"
#include "ttUtil.h"
#include "App.h"
#include "ToolBarCommand.h"

int disableWheelRotateForOne500ms=-1;
int disableMouseMoveFor200ms=-1;
bool ignoreLeftMouseUp=false;
bool ignoreMiddleMouseUp=false;
bool ignoreRightMouseUp=false;

std::vector<SMouseOrKeyboardOrResizeEvent> _bufferedMouseOrKeyboardOrResizeEvents;

#ifdef USING_QOPENGLWIDGET
COpenglWidget::COpenglWidget(QWidget *parent) : QOpenGLWidget(QGLFormat((App::userSettings->stereoDist<=0.0f) ? (QGL::DoubleBuffer) : (QGL::StereoBuffers)),parent)
#else
COpenglWidget::COpenglWidget(QWidget *parent) : QGLWidget(QGLFormat((App::userSettings->stereoDist<=0.0f) ? (QGL::DoubleBuffer) : (QGL::StereoBuffers)),parent)
#endif
{
	_openGlDisplayEnabled=true;
	setMouseTracking(true);
	setFocusPolicy(Qt::WheelFocus);

	QTimer* timer_100ms=new QTimer(this);
	connect(timer_100ms, SIGNAL(timeout()), this, SLOT(_timer100ms_fire()));
	timer_100ms->start(100);

}

COpenglWidget::~COpenglWidget()
{
}

void COpenglWidget::setOpenGlDisplayEnabled(bool e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	_openGlDisplayEnabled=e;
	App::ct->objCont->toolbarRefreshFlag=true;
	App::ct->hierarchy->setRefreshViewFlag();
	App::ct->browser->setRefreshViewFlag();
}

bool COpenglWidget::getOpenGlDisplayEnabled()
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	return(_openGlDisplayEnabled);
}

void COpenglWidget::initializeGL()
{
	setAutoBufferSwap(false);
}

void COpenglWidget::paintEvent(QPaintEvent* event)
{
//	QGLWidget::paintEvent(event);
}

void COpenglWidget::resizeEvent(QResizeEvent* rEvent)
{
	_handleMouseAndKeyboardAndResizeEvents(rEvent,7);
}

void COpenglWidget::_resizeEvent(SMouseOrKeyboardOrResizeEvent e)
{
	FUNCTION_DEBUG;
//	QGLWidget::resizeEvent(event);

	float sx=windowHandle()->devicePixelRatio();
	float sy=windowHandle()->devicePixelRatio();
	int width=int(float(e.x)*sx+0.5f);
	int height=int(float(e.y)*sy+0.5f);

	App::mainWindow->simulationRecorder->setRecordingSizeChanged(width,height);
	App::mainWindow->clientArea.x=width;
	App::mainWindow->clientArea.y=height;
	App::mainWindow->clientPos.x=0;
	App::mainWindow->clientPos.y=0;

	App::mainWindow->recomputeClientSizeAndPos();
	App::mainWindow->renderOpenGlContent_callFromRenderingThreadOnly();
	//	App::mainWindow->dlgCont->refresh(); // Removed on 7/6/2014 because of some crashes, and this is anyway not needed
}

void COpenglWidget::paintGL()
{
}

void COpenglWidget::mouseMoveEvent(QMouseEvent* mEvent)
{
	_handleMouseAndKeyboardAndResizeEvents(mEvent,3);
}

void COpenglWidget::_mouseMoveEvent(SMouseOrKeyboardOrResizeEvent e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	float sx=windowHandle()->devicePixelRatio();
	float sy=windowHandle()->devicePixelRatio();
	int x=int(float(e.x)*sx+0.5f);
	int y=int(float(e.y)*sy+0.5f);

	App::mainWindow->ctrlKeyDown=e.ctrlDown;
	App::mainWindow->shiftKeyDown=e.shiftDown;
	int cur=-1;
	{
		if ( (disableMouseMoveFor200ms==-1)||(VDateTime::getTimeDiffInMs(disableMouseMoveFor200ms)>200) )
		{ // when a mouse button was released, sometimes the mouse moves involontarily
			disableMouseMoveFor200ms=-1;
			App::mainWindow->onMouseMoveTT(x,y); // This will also call recomputeMousePos
			if (_openGlDisplayEnabled)
				cur=App::ct->oglSurface->getCursor(x,App::mainWindow->clientArea.y-y);
		}
	}
	if (cur!=-1)
		App::mainWindow->_currentCursor=cur;
	else
		App::mainWindow->_currentCursor=sim_cursor_arrow;
	static int previousCursor=-1;
	if (previousCursor!=App::mainWindow->_currentCursor)
	{
		setCursor(Qt::PointingHandCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_arrow)
			setCursor(Qt::ArrowCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_finger)
			setCursor(Qt::PointingHandCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_all_directions)
			setCursor(Qt::SizeAllCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_horizontal_directions)
			setCursor(Qt::SizeHorCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_vertical_directions)
			setCursor(Qt::SizeVerCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_slash_directions)
			setCursor(Qt::SizeBDiagCursor);
		if (App::mainWindow->_currentCursor==sim_cursor_backslash_directions)
			setCursor(Qt::SizeFDiagCursor);
		previousCursor=App::mainWindow->_currentCursor;
	}
}

void COpenglWidget::mousePressEvent(QMouseEvent* mEvent)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	_handleMouseAndKeyboardAndResizeEvents(mEvent,0);
}

void COpenglWidget::_mousePressEvent(SMouseOrKeyboardOrResizeEvent e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	float sx=windowHandle()->devicePixelRatio();
	float sy=windowHandle()->devicePixelRatio();
	int x=int(float(e.x)*sx+0.5f);
	int y=int(float(e.y)*sy+0.5f);

	App::mainWindow->ctrlKeyDown=e.ctrlDown;
	App::mainWindow->shiftKeyDown=e.shiftDown;
	if (e.button==0)
	{ // Left button down
		if (!(CMainWindow::middleMouseDown|CMainWindow::rightMouseDown))
		{ // registered only if no other mouse button is down
			CMainWindow::leftMouseDown=true;
			App::mainWindow->onLeftMouseButtonDownTT(x,y);
			App::mainWindow->_mouseButtonsState|=1;
			ignoreLeftMouseUp=false;
		}
		else
			ignoreLeftMouseUp=true;
	}
	if (!(App::isFullScreen()))
	{
		if (e.button==2)
		{ // right button down
			if (!(CMainWindow::middleMouseDown|CMainWindow::leftMouseDown))
			{ // registered only if no other mouse button is down
				CMainWindow::rightMouseDown=true;

				if (App::userSettings->navigationBackwardCompatibility)
				{
					App::mainWindow->_savedMouseMode=App::ct->getMouseMode();
					int upperMouseMode=((App::ct->getMouseMode()&0xff00)|sim_navigation_clickselection)-sim_navigation_clickselection; // sim_navigation_clickselection because otherwise we have a problem (12/06/2011)
					if (App::ct->getMouseMode()&sim_navigation_camerarotaterightbutton)
						App::ct->setMouseMode(upperMouseMode|sim_navigation_camerarotate); // default
					else
						App::ct->setMouseMode(upperMouseMode|sim_navigation_passive);
				}

				App::mainWindow->onRightMouseButtonDownTT(x,y);
				App::mainWindow->_mouseButtonsState|=4;
				ignoreRightMouseUp=false;
			}
			else
				ignoreRightMouseUp=true;
		}
	}
	if (e.button==1)
	{ // middle button down

		if (!(CMainWindow::rightMouseDown|CMainWindow::leftMouseDown))
		{ // registered only if no other mouse button is down
			if (!App::userSettings->navigationBackwardCompatibility)
			{ // Regular routine
				CMainWindow::middleMouseDown=true;
				App::mainWindow->_savedMouseMode=App::ct->getMouseMode();
				int upperMouseMode=((App::ct->getMouseMode()&0xff00)|sim_navigation_clickselection)-sim_navigation_clickselection; // sim_navigation_clickselection because otherwise we have a problem (12/06/2011)
				if (App::ct->getMouseMode()&sim_navigation_camerarotaterightbutton)
					App::ct->setMouseMode(upperMouseMode|sim_navigation_camerarotate); // default
				else
					App::ct->setMouseMode(upperMouseMode|sim_navigation_passive);
				App::mainWindow->onMiddleMouseButtonDownTT(x,y);
				App::mainWindow->_mouseButtonsState|=8;
			}
			else
			{ // Routine that supports the old navigation mode
				if ( (App::userSettings->middleMouseButtonSwitchesModes)&&(!(App::isFullScreen())) )
				{
					CMainWindow::middleMouseDown=true;
					bool noSelector=true;
					if (App::ct->oglSurface->isSceneSelectionActive()||App::ct->oglSurface->isPageSelectionActive()||App::ct->oglSurface->isViewSelectionActive())
						noSelector=false;
					if (noSelector)
					{
						if ((App::ct->getMouseMode()&0x00ff)==sim_navigation_camerashift)
							App::ct->setMouseMode((App::ct->getMouseMode()&0xff00)|sim_navigation_objectshift);
						else
						{
							if ((App::ct->getMouseMode()&0x00ff)==sim_navigation_objectshift)
								App::ct->setMouseMode((App::ct->getMouseMode()&0xff00)|sim_navigation_objectrotate);
							else
								App::ct->setMouseMode((App::ct->getMouseMode()&0xff00)|sim_navigation_camerashift);
						}
					}
					App::mainWindow->_mouseButtonsState|=8;
				}
			}
			ignoreMiddleMouseUp=false;
		}
		else
			ignoreMiddleMouseUp=true;
	}

	CDlgEx::doTransparencyCounter++;
}

void COpenglWidget::mouseReleaseEvent(QMouseEvent* mEvent)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	_handleMouseAndKeyboardAndResizeEvents(mEvent,1);
}

void COpenglWidget::_mouseReleaseEvent(SMouseOrKeyboardOrResizeEvent e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	float sx=windowHandle()->devicePixelRatio();
	float sy=windowHandle()->devicePixelRatio();
	int x=int(float(e.x)*sx+0.5f);
	int y=int(float(e.y)*sy+0.5f);

	App::mainWindow->ctrlKeyDown=e.ctrlDown;
	App::mainWindow->shiftKeyDown=e.shiftDown;

	if (e.button==0)
	{
		if (!ignoreLeftMouseUp)
		{
			CMainWindow::leftMouseDown=false;
			disableMouseMoveFor200ms=VDateTime::getTimeInMs(); // when the left mouse button was released, sometimes the mouse moves involontarily
			disableMouseMoveFor200ms=VDateTime::getTimeInMs();
			App::mainWindow->onLeftMouseButtonUpTT(x,y);
			App::mainWindow->_mouseButtonsState&=0xffff-1;
		}
	}
	if (!(App::isFullScreen()))
	{
		if (!ignoreRightMouseUp)
		{
			if (e.button==2)
			{
				CMainWindow::rightMouseDown=false;
				disableMouseMoveFor200ms=VDateTime::getTimeInMs(); // when the right mouse button was released, sometimes the mouse moves involontarily

				App::mainWindow->onRightMouseButtonUpTT(x,y);
				if ( App::userSettings->navigationBackwardCompatibility&&(!(App::isFullScreen())) )
					App::ct->setMouseMode(App::mainWindow->_savedMouseMode);

				App::mainWindow->_mouseButtonsState&=0xffff-4;
			}
		}
	}
	if (e.button==1)
	{
		if (!ignoreMiddleMouseUp)
		{
			if (!App::userSettings->navigationBackwardCompatibility)
			{
				disableWheelRotateForOne500ms=VDateTime::getTimeInMs(); // when the middle mouse button was released, sometimes the wheel rotates involontarily
				disableMouseMoveFor200ms=VDateTime::getTimeInMs(); // when the middle mouse button was released, sometimes the mouse moves involontarily
				CMainWindow::middleMouseDown=false;
				App::mainWindow->onMiddleMouseButtonUpTT(x,y);

				App::ct->setMouseMode(App::mainWindow->_savedMouseMode);
			}
			CMainWindow::middleMouseDown=false;
			App::mainWindow->_mouseButtonsState&=0xffff-8;
		}
	}
}

void COpenglWidget::mouseDoubleClickEvent(QMouseEvent* mEvent)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	_handleMouseAndKeyboardAndResizeEvents(mEvent,2);
}

void COpenglWidget::_mouseDoubleClickEvent(SMouseOrKeyboardOrResizeEvent e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	float sx=windowHandle()->devicePixelRatio();
	float sy=windowHandle()->devicePixelRatio();
	int x=int(float(e.x)*sx+0.5f);
	int y=int(float(e.y)*sy+0.5f);

	App::mainWindow->ctrlKeyDown=e.ctrlDown;
	App::mainWindow->shiftKeyDown=e.shiftDown;

	if (!(App::isFullScreen()))
	{
		if (e.button==0)
		{ // left button
			App::mainWindow->onLeftMouseButtonDoubleClickTT(x,y);
		}
		if (e.button==1)
		{ // Middle button. similar thing further up (in mouse press)
			CMainWindow::middleMouseDown=true;

			if (App::userSettings->navigationBackwardCompatibility)
			{ // to support the old navigation method
				if (App::userSettings->middleMouseButtonSwitchesModes)
				{
					bool noSelector=true;
					if (App::ct->oglSurface->isSceneSelectionActive()||App::ct->oglSurface->isPageSelectionActive()||App::ct->oglSurface->isViewSelectionActive())
						noSelector=false;
					if (noSelector)
					{
						if ((App::ct->getMouseMode()&0x00ff)==sim_navigation_camerashift)
							App::ct->setMouseMode((App::ct->getMouseMode()&0xff00)|sim_navigation_objectshift);
						else
						{
							if ((App::ct->getMouseMode()&0x00ff)==sim_navigation_objectshift)
								App::ct->setMouseMode((App::ct->getMouseMode()&0xff00)|sim_navigation_objectrotate);
							else
								App::ct->setMouseMode((App::ct->getMouseMode()&0xff00)|sim_navigation_camerashift);
						}
					}
				}
			}
		}
	}
}

void COpenglWidget::wheelEvent(QWheelEvent* wEvent)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	_handleMouseAndKeyboardAndResizeEvents(wEvent,4);
}

void COpenglWidget::_wheelEvent(SMouseOrKeyboardOrResizeEvent e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	if (!(CMainWindow::leftMouseDown|CMainWindow::middleMouseDown|CMainWindow::rightMouseDown))
	{ // wheel only workd when no other button is down
		if ( (disableWheelRotateForOne500ms==-1)||(VDateTime::getTimeDiffInMs(disableWheelRotateForOne500ms)>300) )
		{ // when the middle mouse button was released, sometimes the wheel rotates involontarily
			disableWheelRotateForOne500ms=-1;
			if (!CMainWindow::middleMouseDown)
			{
				float sx=1.0f;
				float sy=1.0f;
				int x=int(float(e.x)*sx+0.5f);
				int y=int(float(e.y)*sy+0.5f);

				App::mainWindow->ctrlKeyDown=e.ctrlDown;
				App::mainWindow->shiftKeyDown=e.shiftDown;

				if (App::ct->getMouseMode()&sim_navigation_camerazoomwheel)
				{
					if (_openGlDisplayEnabled)
						App::ct->oglSurface->mouseWheel(e.wheelDelta,x,App::mainWindow->clientArea.y-y);
				}
				App::mainWindow->_mouseButtonsState|=2;
				App::mainWindow->_mouseWheelEventTime=VDateTime::getTimeInMs();
			}
		}
	}
}

void COpenglWidget::keyPressEvent(QKeyEvent* kEvent)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	_handleMouseAndKeyboardAndResizeEvents(kEvent,5);
}

void COpenglWidget::_keyPressEvent(SMouseOrKeyboardOrResizeEvent e)
{ // YOU ARE ONLY ALLOWED TO MODIFY SIMPLE TYPES. NO OBJECT CREATION/DESTRUCTION HERE!!
	if (e.specialKey!=-1)
		App::ct->oglSurface->keyPress(e.specialKey,App::mainWindow);
	else
	{
		bool processed=false;
		if (e.key==Qt::Key_Control)
		{
			App::mainWindow->ctrlKeyDown=true;
			processed=true;
		}
		if (e.key==Qt::Key_Shift)
		{
			App::mainWindow->shiftKeyDown=true;
			processed=true;
		}
		if (e.key==Qt::Key_Delete)
		{
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(DELETE_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Left)
		{
			App::mainWindow->leftKeyDown=true;
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(LEFT_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Right)
		{
			App::mainWindow->rightKeyDown=true;
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(RIGHT_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Up)
		{
			App::mainWindow->upKeyDown=true;
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(UP_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Down)
		{
			App::mainWindow->downKeyDown=true;
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(DOWN_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Escape)
		{
			if (!_openGlDisplayEnabled)
				_openGlDisplayEnabled=true;	// Esc enables the display again
			App::ct->oglSurface->setFocusObject(FOCUS_ON_PAGE);
			App::mainWindow->focusObject=App::ct->oglSurface->getFocusObject();
			App::ct->oglSurface->keyPress(ESC_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Tab)
		{
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(TAB_KEY,App::mainWindow);
			processed=true;
		}
		if ((e.key==Qt::Key_Enter)||(e.key==Qt::Key_Return))
		{
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(ENTER_KEY,App::mainWindow);
			processed=true;
		}
		if (e.key==Qt::Key_Backspace)
		{
			if (_openGlDisplayEnabled)
				App::ct->oglSurface->keyPress(BACKSPACE_KEY,App::mainWindow);
			processed=true;
		}
		if (App::mainWindow->ctrlKeyDown)
		{ // Very specific to V-REP, except for ctrl+Q (which doesn't exist by default on Windows)
			if (e.key==81)
			{
				App::ct->oglSurface->keyPress(CTRL_Q_KEY,App::mainWindow);
				processed=true;
			}
			if (e.key==32)
			{
				App::ct->oglSurface->keyPress(CTRL_SPACE_KEY,App::mainWindow);
				processed=true;
			}
			if (e.key==68)
			{
				App::ct->oglSurface->keyPress(CTRL_D_KEY,App::mainWindow);
				processed=true;
			}
			if (e.key==71)
			{
				App::ct->oglSurface->keyPress(CTRL_G_KEY,App::mainWindow);
				processed=true;
			}
			if (e.key==69)
			{
				App::ct->oglSurface->keyPress(CTRL_E_KEY,App::mainWindow);
				processed=true;
			}
			if (e.key==66)
			{
				CToolBarCommand::processCommand(CAMERA_SHIFT_TO_FRAME_SELECTION_CMD);
//				App::ct->oglSurface->keyPress(CTRL_B_KEY,App::mainWindow);
				processed=true;
			}
		}

		if (!processed)
		{
			QByteArray ba(e.unicodeText.toLatin1());
			if (ba.length()>=1)
			{
				if (_openGlDisplayEnabled)
					App::ct->oglSurface->keyPress(int(ba.at(0)),App::mainWindow);
			}
		}
	}
}

void COpenglWidget::keyReleaseEvent(QKeyEvent* kEvent)
{
	_handleMouseAndKeyboardAndResizeEvents(kEvent,6);
}

void COpenglWidget::_keyReleaseEvent(SMouseOrKeyboardOrResizeEvent e)
{
	int key=e.key;
	if (key==Qt::Key_Control)
		App::mainWindow->ctrlKeyDown=false;
	if (key==Qt::Key_Shift)
		App::mainWindow->shiftKeyDown=false;
	if (key==Qt::Key_Left)
		App::mainWindow->leftKeyDown=false;
	if (key==Qt::Key_Right)
		App::mainWindow->rightKeyDown=false;
	if (key==Qt::Key_Up)
		App::mainWindow->upKeyDown=false;
	if (key==Qt::Key_Down)
		App::mainWindow->downKeyDown=false;
}

void COpenglWidget::_timer100ms_fire()
{
	if (!CSimAndUiThreadSync::hasUiLockedResourcesForReadOrWrite())
		_handleMouseAndKeyboardAndResizeEvents(NULL,8);
}

void COpenglWidget::_handleMouseAndKeyboardAndResizeEvents(void* event,int t)
{
	if (event!=NULL)
	{
		SMouseOrKeyboardOrResizeEvent e;
		e.eventType=t;
		if (t<=3)
		{ // mouse events
			QMouseEvent* mEvent=(QMouseEvent*)event;
			e.x=mEvent->x();
			e.y=mEvent->y();
			e.ctrlDown=((mEvent->modifiers()&Qt::ControlModifier)!=0);
			e.shiftDown=((mEvent->modifiers()&Qt::ShiftModifier)!=0);
			if (mEvent->button()==Qt::LeftButton)
				e.button=0;
			if (mEvent->button()==Qt::MiddleButton)
				e.button=1;
			if (mEvent->button()==Qt::RightButton)
				e.button=2;
		}
		if (t==4)
		{ // mouse wheel events
			QWheelEvent* wEvent=(QWheelEvent*)event;
			e.x=wEvent->x();
			e.y=wEvent->y();
			e.ctrlDown=((wEvent->modifiers()&Qt::ControlModifier)!=0);
			e.shiftDown=((wEvent->modifiers()&Qt::ShiftModifier)!=0);
			e.wheelDelta=wEvent->delta();
		}
		if ((t>=5)&&(t<=6))
		{ // keyboard events
			QKeyEvent* kEvent=(QKeyEvent*)event;
			if (t==5)
			{ // press
				bool processed=false;
				e.key=-1;
				e.specialKey=-1;
				if (kEvent->matches(QKeySequence::Cut))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_X_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Copy))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_C_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Paste))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_V_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Undo))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_Z_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Redo))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_Y_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Save))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_S_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::SelectAll))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_A_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Open))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_O_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::Close))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_W_KEY;
					processed=true;
				}
				if (kEvent->matches(QKeySequence::New))
				{
					if (_openGlDisplayEnabled)
						e.specialKey=CTRL_N_KEY;
					processed=true;
				}
				if (!processed)
				{
					e.key=kEvent->key();
					e.unicodeText=kEvent->text();
				}
			}
			else
			{ // release
				e.key=kEvent->key();
			}
		}
		if (t==7)
		{ // OpenGl surface resize
			QResizeEvent* rEvent=(QResizeEvent*)event;
			e.x=rEvent->size().width();
			e.y=rEvent->size().height();
		}
		_bufferedMouseOrKeyboardOrResizeEvents.push_back(e);
	}
	else
	{ // timer event
		SMouseOrKeyboardOrResizeEvent e;
		e.eventType=t;
		_bufferedMouseOrKeyboardOrResizeEvents.push_back(e);
	}

	if (_bufferedMouseOrKeyboardOrResizeEvents.size()!=0)
	{
		IF_UI_EVENT_CAN_READ_DATA_NO_WAIT
		{
			while (_bufferedMouseOrKeyboardOrResizeEvents.size()!=0)
			{
				SMouseOrKeyboardOrResizeEvent e=_bufferedMouseOrKeyboardOrResizeEvents[0];
				_bufferedMouseOrKeyboardOrResizeEvents.erase(_bufferedMouseOrKeyboardOrResizeEvents.begin());
				if (e.eventType==0)
					_mousePressEvent(e);
				if (e.eventType==1)
					_mouseReleaseEvent(e);
				if (e.eventType==2)
					_mouseDoubleClickEvent(e);
				if (e.eventType==3)
					_mouseMoveEvent(e);
				if (e.eventType==4)
					_wheelEvent(e);
				if (e.eventType==5)
					_keyPressEvent(e);
				if (e.eventType==6)
					_keyReleaseEvent(e);
				if (e.eventType==7)
					_resizeEvent(e);
			}
		}
	}
}
