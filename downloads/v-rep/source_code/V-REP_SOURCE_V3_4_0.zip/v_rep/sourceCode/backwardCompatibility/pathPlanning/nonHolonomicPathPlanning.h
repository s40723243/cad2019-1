// This file is part of V-REP, the Virtual Robot Experimentation Platform.
// 
// Copyright 2006-2017 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// V-REP is dual-licensed, under the terms of EITHER (at your option):
//   1. V-REP commercial license (contact us for details)
//   2. GNU GPL (see below)
// 
// GNU GPL license:
// -------------------------------------------------------------------
// V-REP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// V-REP IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
// WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// 
// See the GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with V-REP.  If not, see <http://www.gnu.org/licenses/>.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.4.0 rev. 1 on April 5th 2017

#pragma once

#include "pathPlanning.h"
#include "nonHolonomicPathNode.h"
#include "dummyClasses.h"
#include <vector>
#include "7Vector.h"

class CNonHolonomicPathPlanning : public CPathPlanning  
{
public:
    CNonHolonomicPathPlanning(int theStartDummyID,int theGoalDummyID,
                            int theRobotCollectionID,int theObstacleCollectionID,int ikGroupID,float theAngularCoeff,
                            float theSteeringAngleCoeff,float theMaxSteeringAngleVariation,float theMaxSteeringAngle,
                            float theStepSize,const float theSearchMinVal[2],const float theSearchRange[2],
                            const int theDirectionConstraints[2],const float clearanceAndMaxDistance[2]);
    virtual ~CNonHolonomicPathPlanning();

    // Following functions are inherited from CPathPlanning:
    int searchPath(int maxTimePerPass);
    bool setPartialPath();
    int smoothFoundPath(int steps,int maxTimePerPass);
    void getPathData(std::vector<float>& data);
    void getSearchTreeData(std::vector<float>& data,bool fromStart);

    void setStepSize(float size);

    std::vector<CNonHolonomicPathNode*> fromStart;
    std::vector<CNonHolonomicPathNode*> fromGoal;
    std::vector<CNonHolonomicPathNode*> foundPath;

private:
    bool doCollide(float* dist);

    CNonHolonomicPathNode* getClosestNode(std::vector<CNonHolonomicPathNode*>& nodes,CNonHolonomicPathNode* sample,bool forward,bool forConnection);
    CNonHolonomicPathNode* extend(std::vector<CNonHolonomicPathNode*>* currentList,CNonHolonomicPathNode* toBeExtended,CNonHolonomicPathNode* extention,bool forward,CDummyDummy* startDummy);
    CNonHolonomicPathNode* connect(std::vector<CNonHolonomicPathNode*>* currentList,std::vector<CNonHolonomicPathNode*>* nextList,CNonHolonomicPathNode* toBeExtended,CNonHolonomicPathNode* extention,bool forward,bool connect,bool test,CDummyDummy* startDummy);

    int _startDummyID;
    float angularCoeff;
    float steeringAngleCoeff;
    float maxSteeringAngleVariation;
    float maxSteeringAngle;
    float minTurningRadius;
    float stepSize;
    int DoF;
    float searchMinVal[2];
    float searchRange[2];
    C7Vector _startDummyCTM;
    C7Vector _startDummyLTM;

    int numberOfRandomConnectionTries_forSteppedSmoothing;
    int numberOfRandomConnectionTriesLeft_forSteppedSmoothing;
    std::vector<int> foundPathSameStraightLineID_forSteppedSmoothing;
    int sameStraightLineNextID_forSteppedSmoothing;
    int nextIteration_forSteppedSmoothing;




    float _startConfInterferenceState;

    int directionConstraints[2]; // WRONG!!! NOT USED NOW!!! 0 is for vehicle direction, 1 is for steering direction
};
