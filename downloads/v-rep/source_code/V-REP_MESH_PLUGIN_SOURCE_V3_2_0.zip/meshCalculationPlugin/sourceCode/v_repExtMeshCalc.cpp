// This file is part of the MESH CALCULATION PLUGIN for V-REP
// 
// Copyright 2006-2014 Coppelia Robotics GmbH. All rights reserved. 
// marc@coppeliarobotics.com
// www.coppeliarobotics.com
// 
// The MESH CALCULATION PLUGIN is licensed under the terms of EITHER:
//   1. MESH CALCULATION PLUGIN commercial license (contact us for details)
//   2. MESH CALCULATION PLUGIN educational license (see below)
// 
// MESH CALCULATION PLUGIN educational license:
// -------------------------------------------------------------------
// The MESH CALCULATION PLUGIN educational license applies only to EDUCATIONAL
// ENTITIES composed by following people and institutions:
// 
// 1. Hobbyists, students, teachers and professors
// 2. Schools and universities
// 
// EDUCATIONAL ENTITIES do NOT include companies, research institutions,
// non-profit organisations, foundations, etc.
// 
// An EDUCATIONAL ENTITY may use, modify, compile and distribute the
// modified/unmodified MESH CALCULATION PLUGIN under following conditions:
//  
// 1. Distribution should be free of charge.
// 2. Distribution should be to EDUCATIONAL ENTITIES only.
// 3. Usage should be non-commercial.
// 4. Altered source versions must be plainly marked as such and distributed
//    along with any compiled code.
// 5. When using the MESH CALCULATION PLUGIN in conjunction with V-REP, the "EDU"
//    watermark in the V-REP scene view should not be removed.
// 6. The origin of the MESH CALCULATION PLUGIN must not be misrepresented. you must
//    not claim that you wrote the original software.
// 
// THE MESH CALCULATION PLUGIN IS DISTRIBUTED "AS IS", WITHOUT ANY EXPRESS
// OR IMPLIED WARRANTY. THE USER WILL USE IT AT HIS/HER OWN RISK. THE ORIGINAL
// AUTHORS AND COPPELIA ROBOTICS GMBH WILL NOT BE LIABLE FOR DATA LOSS,
// DAMAGES, LOSS OF PROFITS OR ANY OTHER KIND OF LOSS WHILE USING OR
// MISUSING THIS SOFTWARE.
// -------------------------------------------------------------------
//
// This file was automatically created for V-REP release V3.2.0 on Feb. 3rd 2015

#include "v_repExtMeshCalc.h"
#include "v_repLib.h"
#include <iostream>
#include "collDistInterface.h"
#include <cstdio>

#ifdef _WIN32
	#include <direct.h>
#endif

#define MESH_CALC_PLUGIN_VERSION 1

LIBRARY vrepLib;

VREP_DLLEXPORT unsigned char v_repStart(void* reservedPointer,int reservedInt)
{ // This is called just once, at the start of V-REP.

	// Dynamically load and bind V-REP functions:
	 char curDirAndFile[1024];
 #ifdef _WIN32
	 _getcwd(curDirAndFile, sizeof(curDirAndFile));
 #elif defined (__linux) || defined (__APPLE__)
	 getcwd(curDirAndFile, sizeof(curDirAndFile));
 #endif
	 std::string currentDirAndPath(curDirAndFile);
	 // 2. Append the V-REP library's name:
	 std::string temp(currentDirAndPath);
 #ifdef _WIN32
	 temp+="/v_rep.dll";
 #elif defined (__linux)
	 temp+="/libv_rep.so";
 #elif defined (__APPLE__)
	 temp+="/libv_rep.dylib";
 #endif /* __linux || __APPLE__ */
	 // 3. Load the V-REP library:
	 vrepLib=loadVrepLibrary(temp.c_str());
	 if (vrepLib==NULL)
	 {
		 std::cout << "Error, could not find or correctly load the V-REP library. Cannot start 'MeshCalc' plugin.\n";
		 return(0); // Means error, V-REP will unload this plugin
	 }
	 if (getVrepProcAddresses(vrepLib)==0)
	 {
		 std::cout << "Error, could not find all required functions in the V-REP library. Cannot start 'MeshCalc' plugin.\n";
		 unloadVrepLibrary(vrepLib);
		 return(0); // Means error, V-REP will unload this plugin
	 }
	 // ******************************************

	 // Check the version of V-REP:
	 // ******************************************
	 int vrepVer;
	 simGetIntegerParameter(sim_intparam_program_version,&vrepVer);
	 if (vrepVer<20607) // if V-REP version is smaller than 2.06.07
	 {
		 std::cout << "Sorry, your V-REP copy is somewhat old. Cannot start 'MeshCalc' plugin.\n";
		 unloadVrepLibrary(vrepLib);
		 return(0); // Means error, V-REP will unload this plugin
	 }
	 // ******************************************

	return(MESH_CALC_PLUGIN_VERSION);	// initialization went fine, we return the version number of this plugin (can be queried with simGetModuleName)
}

VREP_DLLEXPORT void v_repEnd()
{
	unloadVrepLibrary(vrepLib); 
}

VREP_DLLEXPORT void* v_repMessage(int message,int* auxiliaryData,void* customData,int* replyData)
{
	void* retVal=NULL;
	if (message==sim_message_eventcallback_meshcalculationplugin)
	{
		if (auxiliaryData[0]==0)
			replyData[0]=MESH_CALC_PLUGIN_VERSION; // this is the version number of this plugin
		int v=1;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_createCollisionInformationStructure);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_copyCollisionInformationStructure);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_destroyCollisionInformationStructure);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_scaleCollisionInformationStructure);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCollisionInformationStructureSerializationData);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCollisionInformationStructureFromSerializationData);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_releaseBuffer);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCutMesh);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedTriangleCount);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedTrianglesPointer);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedVerticeCount);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedVerticesPointer);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedSegmentCount);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedSegmentsPointer);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedPolygonCount);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedPolygonSize);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedPolygonArrayPointer);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getCalculatedTriangleAt);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getMeshMeshCollision);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getTriangleTriangleCollision);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getMeshMeshDistance);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getDistanceAgainstDummy_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getBoxPointDistance);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getApproximateBoxBoxDistance);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getTriangleTriangleDistance_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getTrianglePointDistance_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getRayProxSensorDistance_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_isPointInsideVolume1AndOutsideVolume2);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_isPointTouchingVolume);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getProxSensorDistance_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getProxSensorDistanceToSegment_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getProxSensorDistanceToTriangle_ifSmaller);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_cutNodeWithVolume);
		v++;
		if (auxiliaryData[0]==v)
			return((void*)CCollDistInterface::_getBoxBoxCollision);
		v++;
	}
	return(retVal);
}
