convert file.stl to wrl

    meshconv file.stl -c wrl

convert file.wrl to stl
 
    meshconv file.wrl -c stl