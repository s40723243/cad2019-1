from nx3 import *
print(nx3(1,10))
print(nx4(10,1))

