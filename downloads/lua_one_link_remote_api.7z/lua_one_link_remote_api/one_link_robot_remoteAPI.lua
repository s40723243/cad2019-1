-- Make sure to have the server side running in V-REP: 
-- in a child script of a V-REP scene, add following command
-- to be executed just once, at simulation start:
--
-- simRemoteApi.start(19999)
--
-- then start simulation, and run this program.
--
-- IMPORTANT: for each successful call to simxStart, there
-- should be a corresponding call to simxFinish at the end!

print('Program started')
require 'remoteApiLua'

simxFinish(-1) -- just in case, close all opened connections

local clientID=simxStart('127.0.0.1',19998,true,true,2000,5)
if clientID~=-1 then
    print('Connected to remote API server')
else
    print('Connection not successful')
    os.exit('Could not connect')
end

errorCode,Revolute_joint_handle = simxGetObjectHandle(clientID,'Revolute_joint', simx_opmode_oneshot_wait)
 
if errorCode == -1
    then
    print('Can not find left or right motor')
    os.exit()
end
    
errorCode=simxSetJointTargetVelocity(clientID,Revolute_joint_handle,2, simx_opmode_oneshot_wait)

while true
    do
    io.write("(e to exit, p to pause and enter to exec)>")
    local choice = io.read()
    if choice == "e" 
    then
        print("exiting")
        simxStopSimulation(clientID, simx_opmode_oneshot_wait)
        break
    elseif choice == "p"
    then
        simxPauseSimulation(clientID, simx_opmode_oneshot_wait)
    else
        simxStartSimulation(clientID, simx_opmode_oneshot_wait)
    end
end
